from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "AgentOS API"
    environment: str = "development"
    database_url: str = "sqlite:///./agentos.db"
    redis_url: str = "redis://localhost:6379/0"
    jwt_secret_key: str = "development-only-change-me"
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    google_client_id: str = ""
    google_client_secret: str = ""
    google_redirect_uri: str = "http://localhost:8000/api/v1/auth/google/callback"
    frontend_url: str = "http://localhost:5173"
    cors_origins: str = "http://localhost:5173"
    # Chave usada para criptografar as chaves de API dos provedores de IA guardadas no banco.
    # Se vazia, é derivada de JWT_SECRET_KEY (trocar o segredo invalida as chaves salvas).
    encryption_key: str = ""
    max_agent_steps: int = 6
    public_rate_limit_per_minute: int = 60
    provider_timeout_seconds: int = 90

    model_config = SettingsConfigDict(env_file=".env", extra="ignore", case_sensitive=False)

    @property
    def cors_origin_list(self) -> list[str]:
        return [origin.strip() for origin in self.cors_origins.split(",") if origin.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()

_WEAK_SECRETS = {"development-only-change-me", "replace-with-a-long-random-secret", ""}
if settings.environment != "development" and (settings.jwt_secret_key in _WEAK_SECRETS or len(settings.jwt_secret_key) < 32):
    raise RuntimeError("Defina JWT_SECRET_KEY com um valor aleatório de pelo menos 32 caracteres antes de usar fora do desenvolvimento.")
