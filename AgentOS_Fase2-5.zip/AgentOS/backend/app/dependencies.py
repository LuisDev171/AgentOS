import uuid
import jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session
from app.db import get_db
from app.models import User, Membership
from app.security import decode_token

bearer = HTTPBearer(auto_error=False)


def get_current_user(
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer),
    db: Session = Depends(get_db),
) -> User:
    if not credentials:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Autenticação necessária")
    try:
        payload = decode_token(credentials.credentials, "access")
        user_id = uuid.UUID(payload["sub"])
    except (jwt.PyJWTError, ValueError, KeyError):
        raise HTTPException(status_code=401, detail="Token inválido ou expirado")
    user = db.get(User, user_id)
    if not user or not user.is_active:
        raise HTTPException(status_code=401, detail="Usuário não encontrado ou inativo")
    return user


def get_current_membership(
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> Membership:
    membership = db.query(Membership).filter(Membership.user_id == user.id).order_by(Membership.created_at.asc()).first()
    if not membership:
        raise HTTPException(status_code=403, detail="Usuário não pertence a uma organização")
    return membership


def require_manager(membership: Membership = Depends(get_current_membership)) -> Membership:
    """Apenas proprietário/administrador."""
    if membership.role not in ("owner", "admin"):
        raise HTTPException(status_code=403, detail="Apenas proprietários e administradores podem fazer isso")
    return membership
