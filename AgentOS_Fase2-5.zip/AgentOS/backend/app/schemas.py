import uuid
from pydantic import BaseModel, EmailStr, Field, ConfigDict


class RegisterRequest(BaseModel):
    full_name: str = Field(min_length=2, max_length=160)
    email: EmailStr
    password: str = Field(min_length=10, max_length=128)
    organization_name: str = Field(min_length=2, max_length=160)


class LoginRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=1, max_length=128)


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    requires_2fa: bool = False


class TwoFactorCodeRequest(BaseModel):
    code: str = Field(min_length=6, max_length=8)


class UserResponse(BaseModel):
    id: uuid.UUID
    full_name: str
    email: EmailStr
    two_factor_enabled: bool
    model_config = ConfigDict(from_attributes=True)


class OrganizationResponse(BaseModel):
    id: uuid.UUID
    name: str
    role: str


# ---------------------------------------------------------------- Fase 2+ ----
from datetime import datetime  # noqa: E402
from typing import Literal  # noqa: E402

Provider = Literal["openai", "anthropic", "gemini"]


class ProviderKeyRequest(BaseModel):
    api_key: str = Field(min_length=8, max_length=400)


class AgentIn(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    description: str = Field(default="", max_length=500)
    provider: Provider
    model: str = Field(min_length=2, max_length=120)
    system_prompt: str = Field(default="", max_length=20000)
    temperature: float = Field(default=0.7, ge=0, le=2)
    max_tokens: int = Field(default=1024, ge=16, le=8192)
    tools: list[str] = Field(default_factory=list, max_length=20)
    knowledge_base_ids: list[uuid.UUID] = Field(default_factory=list, max_length=20)
    is_active: bool = True


class AgentOut(BaseModel):
    id: uuid.UUID
    name: str
    description: str
    provider: str
    model: str
    system_prompt: str
    temperature: float
    max_tokens: int
    tools: list[str]
    knowledge_base_ids: list[uuid.UUID]
    is_active: bool
    created_at: datetime
    updated_at: datetime


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=20000)
    conversation_id: uuid.UUID | None = None


class RunRequest(BaseModel):
    input: str = Field(default="", max_length=20000)


class KnowledgeBaseIn(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    description: str = Field(default="", max_length=500)


class DocumentIn(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    content: str = Field(min_length=1, max_length=500_000)


class WorkflowIn(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    description: str = Field(default="", max_length=500)
    steps: list[dict] = Field(default_factory=list)
    is_active: bool = True


class ApiKeyIn(BaseModel):
    name: str = Field(min_length=2, max_length=120)


class PlanChange(BaseModel):
    plan: Literal["free", "pro", "business"]
