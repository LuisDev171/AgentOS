from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.sessions import SessionMiddleware
from app.core.config import settings
from app.db import Base, engine
from app import models  # noqa: F401 - registers SQLAlchemy models
from app.api.v1.routers import agents, auth, billing, executions, health, integrations, knowledge_bases, organizations, public, workflows


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Convenience for local development. Use Alembic migrations in production.
    if settings.environment == "development":
        Base.metadata.create_all(bind=engine)
    yield


app = FastAPI(
    title="AgentOS API",
    description="API da plataforma AgentOS",
    version="0.2.0",
    lifespan=lifespan,
)

app.add_middleware(SessionMiddleware, secret_key=settings.jwt_secret_key, same_site="lax", https_only=False)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health.router)
app.include_router(auth.router, prefix="/api/v1")
app.include_router(organizations.router, prefix="/api/v1")
for _router in (integrations.router, agents.router, knowledge_bases.router, workflows.router, executions.router, billing.router, public.router):
    app.include_router(_router, prefix="/api/v1")


@app.get("/")
def root():
    return {"name": "AgentOS API", "version": "0.2.0", "docs": "/docs"}
