"""Knowledge Base: divisão em trechos e busca por palavras-chave (BM25, sem dependências externas)."""
import math
import re
import unicodedata
import uuid
from collections import Counter

from sqlalchemy.orm import Session

from app.models import KnowledgeChunk

CHUNK_SIZE = 900
CHUNK_OVERLAP = 120
MAX_DOCUMENT_CHARS = 500_000

_STOPWORDS = set(
    "a o as os um uma uns umas de do da dos das em no na nos nas por para com sem sobre e ou que se ao aos "
    "the an of to in on for and or is are was be with as at by from this that it".split()
)


def tokenize(text: str) -> list[str]:
    text = unicodedata.normalize("NFKD", text.lower())
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    return [w for w in re.findall(r"[a-z0-9]+", text) if len(w) > 1 and w not in _STOPWORDS]


def split_into_chunks(text: str, size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP) -> list[str]:
    text = re.sub(r"\r\n?", "\n", text).strip()
    if not text:
        return []
    paragraphs = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    chunks: list[str] = []
    current = ""
    for para in paragraphs:
        while len(para) > size:  # parágrafo gigante: corta com sobreposição
            if current:
                chunks.append(current)
                current = ""
            chunks.append(para[:size])
            para = para[size - overlap:]
        if current and len(current) + len(para) + 2 > size:
            chunks.append(current)
            tail = current[-overlap:] if overlap else ""
            current = (tail + "\n\n" + para).strip() if tail else para
        else:
            current = f"{current}\n\n{para}" if current else para
    if current:
        chunks.append(current)
    return chunks


def bm25_rank(query: str, texts: list[str], k: int = 4, k1: float = 1.5, b: float = 0.75) -> list[tuple[int, float]]:
    q_terms = list(dict.fromkeys(tokenize(query)))
    if not q_terms or not texts:
        return []
    docs = [Counter(tokenize(t)) for t in texts]
    lengths = [sum(d.values()) for d in docs]
    avg = (sum(lengths) / len(lengths)) or 1.0
    n = len(docs)
    scores: list[tuple[int, float]] = []
    for i, d in enumerate(docs):
        score = 0.0
        for term in q_terms:
            tf = d.get(term, 0)
            if not tf:
                continue
            df = sum(1 for other in docs if term in other)
            idf = math.log(1 + (n - df + 0.5) / (df + 0.5))
            score += idf * tf * (k1 + 1) / (tf + k1 * (1 - b + b * lengths[i] / avg))
        if score > 0:
            scores.append((i, score))
    scores.sort(key=lambda x: x[1], reverse=True)
    return scores[:k]


def search(db: Session, organization_id: uuid.UUID, kb_ids: list[uuid.UUID], query: str, k: int = 4) -> list[str]:
    if not kb_ids:
        return []
    chunks = (
        db.query(KnowledgeChunk)
        .filter(KnowledgeChunk.organization_id == organization_id, KnowledgeChunk.knowledge_base_id.in_(kb_ids))
        .all()
    )
    ranked = bm25_rank(query, [c.text for c in chunks], k=k)
    return [chunks[i].text for i, _ in ranked]
