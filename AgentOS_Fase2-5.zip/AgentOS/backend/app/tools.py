"""Ferramentas que um agente pode usar. Cada agente só executa as que foram autorizadas nele."""
import ast
import json
import operator
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Callable

from sqlalchemy.orm import Session

from app import knowledge
from app.netsafe import UnsafeURL, safe_request

MAX_TOOL_OUTPUT = 6000


@dataclass
class ToolContext:
    db: Session
    organization_id: uuid.UUID
    kb_ids: list[uuid.UUID] = field(default_factory=list)


@dataclass
class Tool:
    name: str
    label: str
    description: str
    parameters: dict
    run: Callable[[dict, ToolContext], str]
    # ferramentas "automáticas" não aparecem na lista de seleção; dependem de outra configuração
    automatic: bool = False


# --- current_time ---------------------------------------------------------------
def _current_time(args: dict, ctx: ToolContext) -> str:
    tz_name = str(args.get("timezone") or "UTC")
    try:
        from zoneinfo import ZoneInfo

        now = datetime.now(ZoneInfo(tz_name))
    except Exception:
        now = datetime.now(timezone.utc)
        tz_name = "UTC (fuso informado não reconhecido)"
    return f"{now.strftime('%Y-%m-%d %H:%M:%S')} ({tz_name}), {now.strftime('%A')}"


# --- calculator -----------------------------------------------------------------
_BIN = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv,
        ast.FloorDiv: operator.floordiv, ast.Mod: operator.mod, ast.Pow: operator.pow}
_UN = {ast.UAdd: operator.pos, ast.USub: operator.neg}


def _eval(node):
    if isinstance(node, ast.Expression):
        return _eval(node.body)
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)) and not isinstance(node.value, bool):
        return node.value
    if isinstance(node, ast.BinOp) and type(node.op) in _BIN:
        left, right = _eval(node.left), _eval(node.right)
        if isinstance(node.op, ast.Pow) and (abs(right) > 100 or abs(left) > 1e6):
            raise ValueError("Potência muito grande")
        return _BIN[type(node.op)](left, right)
    if isinstance(node, ast.UnaryOp) and type(node.op) in _UN:
        return _UN[type(node.op)](_eval(node.operand))
    raise ValueError("Expressão não permitida")


def _calculator(args: dict, ctx: ToolContext) -> str:
    expression = str(args.get("expression", "")).strip()
    if not expression or len(expression) > 200:
        return "Erro: informe uma expressão matemática curta."
    try:
        result = _eval(ast.parse(expression, mode="eval"))
    except ZeroDivisionError:
        return "Erro: divisão por zero."
    except (ValueError, SyntaxError, OverflowError):
        return "Erro: expressão inválida. Use apenas números e + - * / // % ** ( )."
    return str(result)


# --- http_get -------------------------------------------------------------------
def _http_get(args: dict, ctx: ToolContext) -> str:
    url = str(args.get("url", "")).strip()
    try:
        status, text = safe_request("GET", url, timeout=15, max_bytes=100_000)
    except UnsafeURL as e:
        return f"Erro: {e}"
    except Exception:
        return "Erro: não foi possível acessar a URL."
    return f"HTTP {status}\n{text}"


# --- search_knowledge -----------------------------------------------------------
def _search_knowledge(args: dict, ctx: ToolContext) -> str:
    query = str(args.get("query", "")).strip()
    if not query:
        return "Erro: informe o que buscar."
    results = knowledge.search(ctx.db, ctx.organization_id, ctx.kb_ids, query, k=4)
    if not results:
        return "Nenhum trecho relevante encontrado na base de conhecimento."
    return "\n\n---\n\n".join(f"[Trecho {i + 1}]\n{r}" for i, r in enumerate(results))


TOOLS: dict[str, Tool] = {t.name: t for t in [
    Tool("current_time", "Data e hora atuais", "Retorna a data e hora atuais em um fuso horário (ex.: America/Sao_Paulo).",
         {"type": "object", "properties": {"timezone": {"type": "string", "description": "Fuso IANA, ex.: America/Sao_Paulo"}}}, _current_time),
    Tool("calculator", "Calculadora", "Calcula uma expressão matemática com + - * / // % ** e parênteses.",
         {"type": "object", "properties": {"expression": {"type": "string", "description": "Ex.: (12.5 * 3) / 2"}}, "required": ["expression"]}, _calculator),
    Tool("http_get", "Acessar URL pública (GET)", "Baixa o conteúdo de texto de uma URL pública http/https.",
         {"type": "object", "properties": {"url": {"type": "string", "description": "URL completa"}}, "required": ["url"]}, _http_get),
    Tool("search_knowledge", "Buscar na base de conhecimento", "Busca trechos relevantes nos documentos da base de conhecimento da empresa. Use antes de responder perguntas sobre documentos internos.",
         {"type": "object", "properties": {"query": {"type": "string", "description": "Palavras-chave da busca"}}, "required": ["query"]}, _search_knowledge, automatic=True),
]}


def selectable_tools() -> list[dict]:
    return [{"name": t.name, "label": t.label, "description": t.description} for t in TOOLS.values() if not t.automatic]


def run_tool(name: str, arguments: dict, ctx: ToolContext) -> str:
    tool = TOOLS.get(name)
    if not tool:
        return f"Erro: ferramenta '{name}' não existe."
    try:
        output = tool.run(arguments, ctx)
    except Exception:
        output = "Erro ao executar a ferramenta."
    return output[:MAX_TOOL_OUTPUT]


def tool_specs(names: list[str]) -> list[dict]:
    return [{"name": TOOLS[n].name, "description": TOOLS[n].description, "parameters": TOOLS[n].parameters} for n in names if n in TOOLS]


__all__ = ["TOOLS", "ToolContext", "run_tool", "tool_specs", "selectable_tools", "json"]
