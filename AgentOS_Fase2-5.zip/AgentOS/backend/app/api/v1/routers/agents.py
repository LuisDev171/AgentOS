import uuid

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app import billing
from app.db import get_db
from app.dependencies import get_current_membership, get_current_user, require_manager
from app.models import Agent, AgentKnowledge, Conversation, KnowledgeBase, Membership, Message, User
from app.providers import PROVIDERS
from app.runtime import execute_agent
from app.schemas import AgentIn, AgentOut, ChatRequest
from app.tools import TOOLS

router = APIRouter(tags=["Agents"])


def _kb_ids(db: Session, agent_id: uuid.UUID) -> list[uuid.UUID]:
    return [r.knowledge_base_id for r in db.query(AgentKnowledge).filter(AgentKnowledge.agent_id == agent_id).all()]


def _out(db: Session, agent: Agent) -> AgentOut:
    return AgentOut(
        id=agent.id, name=agent.name, description=agent.description, provider=agent.provider, model=agent.model,
        system_prompt=agent.system_prompt, temperature=agent.temperature, max_tokens=agent.max_tokens,
        tools=agent.tools or [], knowledge_base_ids=_kb_ids(db, agent.id), is_active=agent.is_active,
        created_at=agent.created_at, updated_at=agent.updated_at,
    )


def _get_agent(db: Session, m: Membership, agent_id: uuid.UUID) -> Agent:
    agent = db.query(Agent).filter(Agent.id == agent_id, Agent.organization_id == m.organization_id).first()
    if not agent:
        raise HTTPException(404, "Agente não encontrado")
    return agent


def _validate(db: Session, m: Membership, payload: AgentIn) -> list[str]:
    if payload.provider not in PROVIDERS:
        raise HTTPException(422, "Provedor inválido")
    tools = list(dict.fromkeys(payload.tools))
    for name in tools:
        if name not in TOOLS or TOOLS[name].automatic:
            raise HTTPException(422, f"Ferramenta inválida: {name}")
    if payload.knowledge_base_ids:
        found = db.query(KnowledgeBase.id).filter(
            KnowledgeBase.organization_id == m.organization_id, KnowledgeBase.id.in_(payload.knowledge_base_ids)
        ).count()
        if found != len(set(payload.knowledge_base_ids)):
            raise HTTPException(422, "Base de conhecimento não encontrada")
    return tools


def _set_kbs(db: Session, agent: Agent, kb_ids: list[uuid.UUID]) -> None:
    db.query(AgentKnowledge).filter(AgentKnowledge.agent_id == agent.id).delete()
    for kb_id in dict.fromkeys(kb_ids):
        db.add(AgentKnowledge(agent_id=agent.id, knowledge_base_id=kb_id))


@router.get("/agents", response_model=list[AgentOut])
def list_agents(m: Membership = Depends(get_current_membership), db: Session = Depends(get_db)):
    agents = db.query(Agent).filter(Agent.organization_id == m.organization_id).order_by(Agent.created_at.desc()).all()
    return [_out(db, a) for a in agents]


@router.post("/agents", response_model=AgentOut, status_code=201)
def create_agent(payload: AgentIn, m: Membership = Depends(require_manager), user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    billing.ensure_can_create(db, m.organization_id, "agents")
    tools = _validate(db, m, payload)
    agent = Agent(
        organization_id=m.organization_id, created_by=user.id, name=payload.name.strip(), description=payload.description.strip(),
        provider=payload.provider, model=payload.model.strip(), system_prompt=payload.system_prompt, temperature=payload.temperature,
        max_tokens=payload.max_tokens, tools=tools, is_active=payload.is_active,
    )
    db.add(agent)
    db.flush()
    _set_kbs(db, agent, payload.knowledge_base_ids)
    db.commit()
    db.refresh(agent)
    return _out(db, agent)


@router.get("/agents/{agent_id}", response_model=AgentOut)
def get_agent(agent_id: uuid.UUID, m: Membership = Depends(get_current_membership), db: Session = Depends(get_db)):
    return _out(db, _get_agent(db, m, agent_id))


@router.put("/agents/{agent_id}", response_model=AgentOut)
def update_agent(agent_id: uuid.UUID, payload: AgentIn, m: Membership = Depends(require_manager), db: Session = Depends(get_db)):
    agent = _get_agent(db, m, agent_id)
    tools = _validate(db, m, payload)
    agent.name, agent.description = payload.name.strip(), payload.description.strip()
    agent.provider, agent.model = payload.provider, payload.model.strip()
    agent.system_prompt, agent.temperature, agent.max_tokens = payload.system_prompt, payload.temperature, payload.max_tokens
    agent.tools, agent.is_active = tools, payload.is_active
    _set_kbs(db, agent, payload.knowledge_base_ids)
    db.commit()
    db.refresh(agent)
    return _out(db, agent)


@router.delete("/agents/{agent_id}", status_code=204)
def delete_agent(agent_id: uuid.UUID, m: Membership = Depends(require_manager), db: Session = Depends(get_db)):
    agent = _get_agent(db, m, agent_id)
    db.delete(agent)
    db.commit()


# ---------------------------------------------------------------- chat -------
@router.post("/agents/{agent_id}/chat")
def chat(agent_id: uuid.UUID, payload: ChatRequest, m: Membership = Depends(get_current_membership),
         user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    agent = _get_agent(db, m, agent_id)
    if not agent.is_active:
        raise HTTPException(409, "Este agente está desativado")
    if payload.conversation_id:
        conv = db.query(Conversation).filter(
            Conversation.id == payload.conversation_id, Conversation.organization_id == m.organization_id,
            Conversation.agent_id == agent.id, Conversation.user_id == user.id,
        ).first()
        if not conv:
            raise HTTPException(404, "Conversa não encontrada")
    else:
        conv = Conversation(organization_id=m.organization_id, agent_id=agent.id, user_id=user.id, title=payload.message.strip()[:60])
        db.add(conv)
        db.commit()
    text, execution = execute_agent(db, agent, payload.message, trigger="manual", conversation=conv)
    db.commit()
    return {
        "conversation_id": conv.id, "reply": text, "execution_id": execution.id,
        "tokens_in": execution.tokens_in, "tokens_out": execution.tokens_out,
        "tools_used": [t["tool"] for t in execution.trace or []],
    }


@router.get("/agents/{agent_id}/conversations")
def list_conversations(agent_id: uuid.UUID, m: Membership = Depends(get_current_membership), user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    agent = _get_agent(db, m, agent_id)
    rows = db.query(Conversation).filter(
        Conversation.agent_id == agent.id, Conversation.organization_id == m.organization_id, Conversation.user_id == user.id
    ).order_by(Conversation.updated_at.desc()).limit(50).all()
    return [{"id": c.id, "title": c.title, "updated_at": c.updated_at} for c in rows]


@router.get("/conversations/{conversation_id}/messages")
def conversation_messages(conversation_id: uuid.UUID, m: Membership = Depends(get_current_membership), user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    conv = db.query(Conversation).filter(
        Conversation.id == conversation_id, Conversation.organization_id == m.organization_id, Conversation.user_id == user.id
    ).first()
    if not conv:
        raise HTTPException(404, "Conversa não encontrada")
    rows = db.query(Message).filter(Message.conversation_id == conv.id).order_by(Message.seq.asc()).all()
    # só o que o usuário precisa ver: perguntas, respostas finais e quais ferramentas foram usadas
    out = []
    for r in rows:
        if r.role == "user":
            out.append({"role": "user", "content": r.content})
        elif r.role == "assistant" and r.content:
            out.append({"role": "assistant", "content": r.content, "tools": [c["name"] for c in (r.tool_calls or [])]})
        elif r.role == "assistant" and r.tool_calls:
            out.append({"role": "tool_use", "content": ", ".join(c["name"] for c in r.tool_calls)})
    return out


@router.delete("/conversations/{conversation_id}", status_code=204)
def delete_conversation(conversation_id: uuid.UUID, m: Membership = Depends(get_current_membership), user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    conv = db.query(Conversation).filter(
        Conversation.id == conversation_id, Conversation.organization_id == m.organization_id, Conversation.user_id == user.id
    ).first()
    if not conv:
        raise HTTPException(404, "Conversa não encontrada")
    db.delete(conv)
    db.commit()
