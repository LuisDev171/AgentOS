import uuid

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.db import get_db
from app.dependencies import get_current_membership, require_manager
from app.knowledge import MAX_DOCUMENT_CHARS, bm25_rank, split_into_chunks
from app.models import KnowledgeBase, KnowledgeChunk, KnowledgeDocument, Membership
from app.schemas import DocumentIn, KnowledgeBaseIn

router = APIRouter(prefix="/knowledge-bases", tags=["Knowledge Base"])


def _get_kb(db: Session, m: Membership, kb_id: uuid.UUID) -> KnowledgeBase:
    kb = db.query(KnowledgeBase).filter(KnowledgeBase.id == kb_id, KnowledgeBase.organization_id == m.organization_id).first()
    if not kb:
        raise HTTPException(404, "Base de conhecimento não encontrada")
    return kb


@router.get("")
def list_kbs(m: Membership = Depends(get_current_membership), db: Session = Depends(get_db)):
    out = []
    for kb in db.query(KnowledgeBase).filter(KnowledgeBase.organization_id == m.organization_id).order_by(KnowledgeBase.created_at.desc()).all():
        docs = db.query(KnowledgeDocument).filter(KnowledgeDocument.knowledge_base_id == kb.id).count()
        out.append({"id": kb.id, "name": kb.name, "description": kb.description, "documents": docs, "created_at": kb.created_at})
    return out


@router.post("", status_code=201)
def create_kb(payload: KnowledgeBaseIn, m: Membership = Depends(require_manager), db: Session = Depends(get_db)):
    kb = KnowledgeBase(organization_id=m.organization_id, name=payload.name.strip(), description=payload.description.strip())
    db.add(kb)
    db.commit()
    return {"id": kb.id, "name": kb.name, "description": kb.description, "documents": 0, "created_at": kb.created_at}


@router.delete("/{kb_id}", status_code=204)
def delete_kb(kb_id: uuid.UUID, m: Membership = Depends(require_manager), db: Session = Depends(get_db)):
    db.delete(_get_kb(db, m, kb_id))
    db.commit()


@router.get("/{kb_id}/documents")
def list_documents(kb_id: uuid.UUID, m: Membership = Depends(get_current_membership), db: Session = Depends(get_db)):
    kb = _get_kb(db, m, kb_id)
    docs = db.query(KnowledgeDocument).filter(KnowledgeDocument.knowledge_base_id == kb.id).order_by(KnowledgeDocument.created_at.desc()).all()
    return [{"id": d.id, "title": d.title, "char_count": d.char_count, "chunk_count": d.chunk_count, "created_at": d.created_at} for d in docs]


@router.post("/{kb_id}/documents", status_code=201)
def add_document(kb_id: uuid.UUID, payload: DocumentIn, m: Membership = Depends(require_manager), db: Session = Depends(get_db)):
    kb = _get_kb(db, m, kb_id)
    if len(payload.content) > MAX_DOCUMENT_CHARS:
        raise HTTPException(413, "Documento muito grande (máx. 500 mil caracteres)")
    chunks = split_into_chunks(payload.content)
    if not chunks:
        raise HTTPException(422, "O documento está vazio")
    doc = KnowledgeDocument(
        organization_id=m.organization_id, knowledge_base_id=kb.id, title=payload.title.strip(),
        char_count=len(payload.content), chunk_count=len(chunks),
    )
    db.add(doc)
    db.flush()
    for i, text in enumerate(chunks):
        db.add(KnowledgeChunk(organization_id=m.organization_id, knowledge_base_id=kb.id, document_id=doc.id, position=i, text=text))
    db.commit()
    return {"id": doc.id, "title": doc.title, "char_count": doc.char_count, "chunk_count": doc.chunk_count, "created_at": doc.created_at}


@router.delete("/{kb_id}/documents/{doc_id}", status_code=204)
def delete_document(kb_id: uuid.UUID, doc_id: uuid.UUID, m: Membership = Depends(require_manager), db: Session = Depends(get_db)):
    kb = _get_kb(db, m, kb_id)
    doc = db.query(KnowledgeDocument).filter(KnowledgeDocument.id == doc_id, KnowledgeDocument.knowledge_base_id == kb.id).first()
    if not doc:
        raise HTTPException(404, "Documento não encontrado")
    db.delete(doc)
    db.commit()


@router.get("/{kb_id}/search")
def search_kb(kb_id: uuid.UUID, q: str, m: Membership = Depends(get_current_membership), db: Session = Depends(get_db)):
    kb = _get_kb(db, m, kb_id)
    chunks = db.query(KnowledgeChunk).filter(KnowledgeChunk.knowledge_base_id == kb.id).all()
    ranked = bm25_rank(q, [c.text for c in chunks], k=5)
    return [{"score": round(score, 3), "text": chunks[i].text} for i, score in ranked]
