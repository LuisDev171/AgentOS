from fastapi import APIRouter
from sqlalchemy import text
from app.db import engine

router = APIRouter(tags=["Health"])


@router.get("/health")
def health():
    try:
        with engine.connect() as connection:
            connection.execute(text("SELECT 1"))
        database = "ok"
    except Exception:
        database = "unavailable"
    return {"status": "ok" if database == "ok" else "degraded", "database": database}
