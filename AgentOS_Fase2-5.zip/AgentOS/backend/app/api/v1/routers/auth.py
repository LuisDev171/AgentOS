import base64
import io
import uuid
import jwt
import pyotp
import qrcode
from authlib.integrations.starlette_client import OAuth
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session
from app.core.config import settings
from app.db import get_db
from app.dependencies import get_current_user
from app.models import User, Organization, Membership
from app.schemas import RegisterRequest, LoginRequest, TokenResponse, UserResponse, TwoFactorCodeRequest
from app.security import hash_password, verify_password, create_token, decode_token, new_totp_secret, verify_totp

router = APIRouter(prefix="/auth", tags=["Authentication"])
oauth = OAuth()
if settings.google_client_id and settings.google_client_secret:
    oauth.register(
        name="google",
        client_id=settings.google_client_id,
        client_secret=settings.google_client_secret,
        server_metadata_url="https://accounts.google.com/.well-known/openid-configuration",
        client_kwargs={"scope": "openid email profile"},
    )


@router.post("/register", response_model=TokenResponse, status_code=201)
def register(payload: RegisterRequest, db: Session = Depends(get_db)):
    email = payload.email.lower()
    if db.query(User).filter(User.email == email).first():
        raise HTTPException(status_code=409, detail="Este e-mail já está cadastrado")
    user = User(full_name=payload.full_name.strip(), email=email, password_hash=hash_password(payload.password))
    organization = Organization(name=payload.organization_name.strip())
    db.add_all([user, organization])
    db.flush()
    db.add(Membership(user_id=user.id, organization_id=organization.id, role="owner"))
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="Este e-mail já está cadastrado")
    return TokenResponse(access_token=create_token(str(user.id)))


@router.post("/login", response_model=TokenResponse)
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == payload.email.lower()).first()
    if not user or not verify_password(payload.password, user.password_hash) or not user.is_active:
        raise HTTPException(status_code=401, detail="E-mail ou senha incorretos")
    if user.two_factor_enabled:
        return TokenResponse(access_token=create_token(str(user.id), "mfa"), requires_2fa=True)
    return TokenResponse(access_token=create_token(str(user.id)))


@router.get("/me", response_model=UserResponse)
def me(user: User = Depends(get_current_user)):
    return user


@router.post("/2fa/setup")
def setup_2fa(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.two_factor_enabled:
        raise HTTPException(status_code=400, detail="A autenticação em dois fatores já está ativada")
    secret = new_totp_secret()
    user.two_factor_secret = secret
    db.commit()
    uri = pyotp.TOTP(secret).provisioning_uri(name=user.email, issuer_name="AgentOS")
    qr = qrcode.make(uri)
    buffer = io.BytesIO()
    qr.save(buffer, format="PNG")
    image = base64.b64encode(buffer.getvalue()).decode("ascii")
    return {"secret": secret, "otpauth_uri": uri, "qr_code_data_url": f"data:image/png;base64,{image}"}


@router.post("/2fa/confirm")
def confirm_2fa(
    payload: TwoFactorCodeRequest,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if not user.two_factor_secret or not verify_totp(user.two_factor_secret, payload.code):
        raise HTTPException(status_code=400, detail="Código inválido")
    user.two_factor_enabled = True
    db.commit()
    return {"message": "Autenticação em dois fatores ativada"}


@router.post("/2fa/verify", response_model=TokenResponse)
def verify_2fa(payload: TwoFactorCodeRequest, request: Request, db: Session = Depends(get_db)):
    authorization = request.headers.get("Authorization", "")
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Token de verificação necessário")
    try:
        token_payload = decode_token(authorization.removeprefix("Bearer ").strip(), "mfa")
        user_id = uuid.UUID(token_payload["sub"])
    except (jwt.PyJWTError, KeyError, ValueError):
        raise HTTPException(status_code=401, detail="Desafio 2FA inválido ou expirado")
    user = db.get(User, user_id)
    if not user or not user.is_active or not user.two_factor_enabled or not user.two_factor_secret:
        raise HTTPException(status_code=401, detail="Usuário inválido")
    if not verify_totp(user.two_factor_secret, payload.code):
        raise HTTPException(status_code=401, detail="Código de autenticação inválido")
    return TokenResponse(access_token=create_token(str(user.id)))


@router.get("/google/login")
async def google_login(request: Request):
    if not settings.google_client_id or not settings.google_client_secret:
        raise HTTPException(status_code=503, detail="Login Google ainda não configurado no .env")
    redirect_uri = settings.google_redirect_uri
    return await oauth.google.authorize_redirect(request, redirect_uri)


@router.get("/google/callback")
async def google_callback(request: Request, db: Session = Depends(get_db)):
    if not settings.google_client_id or not settings.google_client_secret:
        raise HTTPException(status_code=503, detail="Login Google não configurado")
    try:
        token = await oauth.google.authorize_access_token(request)
        user_info = token.get("userinfo")
        if not user_info:
            user_info = await oauth.google.userinfo(token=token)
        email = str(user_info.get("email", "")).lower()
        google_sub = user_info.get("sub")
        name = user_info.get("name") or email.split("@")[0]
        if not email or not user_info.get("email_verified"):
            raise HTTPException(status_code=400, detail="O Google não confirmou este e-mail")
        user = db.query(User).filter(User.email == email).first()
        if not user:
            user = User(full_name=name, email=email, google_sub=google_sub)
            organization = Organization(name=f"Empresa de {name}")
            db.add_all([user, organization])
            db.flush()
            db.add(Membership(user_id=user.id, organization_id=organization.id, role="owner"))
        elif not user.is_active:
            raise HTTPException(status_code=403, detail="Conta desativada")
        elif not user.google_sub:
            user.google_sub = google_sub
        elif user.google_sub != google_sub:
            raise HTTPException(status_code=400, detail="Este e-mail está vinculado a outra conta Google")
        db.commit()
        token_type = "mfa" if user.two_factor_enabled else "access"
        access_token = create_token(str(user.id), token_type)
        parameter = "mfa_token" if user.two_factor_enabled else "token"
        return RedirectResponse(f"{settings.frontend_url}/oauth/callback?{parameter}={access_token}")
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(status_code=400, detail="Não foi possível concluir o login Google")
