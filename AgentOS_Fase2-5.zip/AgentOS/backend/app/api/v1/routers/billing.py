from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app import billing as billing_service
from app.db import get_db
from app.dependencies import get_current_membership
from app.models import Membership, Subscription
from app.schemas import PlanChange
from fastapi import HTTPException

router = APIRouter(prefix="/billing", tags=["Billing"])


@router.get("")
def get_billing(m: Membership = Depends(get_current_membership), db: Session = Depends(get_db)):
    plan = billing_service.get_plan_name(db, m.organization_id)
    return {
        "plan": plan,
        "limits": billing_service.PLANS[plan],
        "usage": billing_service.usage(db, m.organization_id),
        "plans": [{"id": k, **v} for k, v in billing_service.PLANS.items()],
        # Sem processador de pagamento integrado: a troca de plano é só um registro interno.
        "payments_enabled": False,
    }


@router.post("/plan")
def change_plan(payload: PlanChange, m: Membership = Depends(get_current_membership), db: Session = Depends(get_db)):
    if m.role != "owner":
        raise HTTPException(403, "Apenas o proprietário pode alterar o plano")
    sub = db.query(Subscription).filter(Subscription.organization_id == m.organization_id).first()
    if not sub:
        sub = Subscription(organization_id=m.organization_id, plan=payload.plan)
        db.add(sub)
    sub.plan = payload.plan
    db.commit()
    return {"plan": sub.plan}
