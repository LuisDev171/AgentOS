import uuid

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app import billing
from app.db import get_db
from app.dependencies import get_current_membership, require_manager
from app.models import Membership, Workflow
from app.schemas import RunRequest, WorkflowIn
from app.workflows import execute_workflow, validate_steps

router = APIRouter(prefix="/workflows", tags=["Workflows"])


def _out(w: Workflow) -> dict:
    return {"id": w.id, "name": w.name, "description": w.description, "steps": w.steps or [], "is_active": w.is_active,
            "created_at": w.created_at, "updated_at": w.updated_at}


def _get(db: Session, m: Membership, workflow_id: uuid.UUID) -> Workflow:
    w = db.query(Workflow).filter(Workflow.id == workflow_id, Workflow.organization_id == m.organization_id).first()
    if not w:
        raise HTTPException(404, "Workflow não encontrado")
    return w


@router.get("")
def list_workflows(m: Membership = Depends(get_current_membership), db: Session = Depends(get_db)):
    rows = db.query(Workflow).filter(Workflow.organization_id == m.organization_id).order_by(Workflow.created_at.desc()).all()
    return [_out(w) for w in rows]


@router.post("", status_code=201)
def create_workflow(payload: WorkflowIn, m: Membership = Depends(require_manager), db: Session = Depends(get_db)):
    billing.ensure_can_create(db, m.organization_id, "workflows")
    steps = validate_steps(db, m.organization_id, payload.steps)
    w = Workflow(organization_id=m.organization_id, name=payload.name.strip(), description=payload.description.strip(), steps=steps, is_active=payload.is_active)
    db.add(w)
    db.commit()
    db.refresh(w)
    return _out(w)


@router.put("/{workflow_id}")
def update_workflow(workflow_id: uuid.UUID, payload: WorkflowIn, m: Membership = Depends(require_manager), db: Session = Depends(get_db)):
    w = _get(db, m, workflow_id)
    w.steps = validate_steps(db, m.organization_id, payload.steps)
    w.name, w.description, w.is_active = payload.name.strip(), payload.description.strip(), payload.is_active
    db.commit()
    db.refresh(w)
    return _out(w)


@router.delete("/{workflow_id}", status_code=204)
def delete_workflow(workflow_id: uuid.UUID, m: Membership = Depends(require_manager), db: Session = Depends(get_db)):
    db.delete(_get(db, m, workflow_id))
    db.commit()


@router.post("/{workflow_id}/run")
def run_workflow(workflow_id: uuid.UUID, payload: RunRequest, m: Membership = Depends(get_current_membership), db: Session = Depends(get_db)):
    w = _get(db, m, workflow_id)
    if not w.is_active:
        raise HTTPException(409, "Este workflow está desativado")
    output, ex = execute_workflow(db, w, payload.input, trigger="manual")
    return {"output": output, "execution_id": ex.id, "tokens_in": ex.tokens_in, "tokens_out": ex.tokens_out, "trace": ex.trace}
