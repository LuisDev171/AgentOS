from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.db import get_db
from app.dependencies import get_current_membership
from app.models import Membership
from app.schemas import OrganizationResponse

router = APIRouter(prefix="/organizations", tags=["Organizations"])


@router.get("/current", response_model=OrganizationResponse)
def current_organization(
    membership: Membership = Depends(get_current_membership),
    db: Session = Depends(get_db),
):
    organization = membership.organization
    return OrganizationResponse(id=organization.id, name=organization.name, role=membership.role)
