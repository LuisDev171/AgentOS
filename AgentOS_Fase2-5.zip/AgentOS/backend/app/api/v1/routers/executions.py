import uuid
from collections import defaultdict
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.db import get_db
from app.dependencies import get_current_membership
from app.models import Agent, Execution, Membership, Workflow

router = APIRouter(tags=["Executions"])


def _row(e: Execution) -> dict:
    return {"id": e.id, "kind": e.kind, "name": e.name, "trigger": e.trigger, "status": e.status,
            "tokens_in": e.tokens_in, "tokens_out": e.tokens_out, "duration_ms": e.duration_ms, "created_at": e.created_at}


@router.get("/executions")
def list_executions(kind: str | None = None, status: str | None = None, limit: int = Query(50, ge=1, le=200), offset: int = Query(0, ge=0),
                    m: Membership = Depends(get_current_membership), db: Session = Depends(get_db)):
    q = db.query(Execution).filter(Execution.organization_id == m.organization_id)
    if kind in ("agent", "workflow"):
        q = q.filter(Execution.kind == kind)
    if status in ("running", "success", "error"):
        q = q.filter(Execution.status == status)
    total = q.count()
    rows = q.order_by(Execution.created_at.desc()).offset(offset).limit(limit).all()
    return {"total": total, "items": [_row(e) for e in rows]}


@router.get("/executions/{execution_id}")
def get_execution(execution_id: uuid.UUID, m: Membership = Depends(get_current_membership), db: Session = Depends(get_db)):
    e = db.query(Execution).filter(Execution.id == execution_id, Execution.organization_id == m.organization_id).first()
    if not e:
        raise HTTPException(404, "Execução não encontrada")
    return {**_row(e), "input": e.input_text, "output": e.output_text, "error": e.error, "trace": e.trace or []}


@router.get("/metrics/overview")
def overview(days: int = Query(14, ge=1, le=90), m: Membership = Depends(get_current_membership), db: Session = Depends(get_db)):
    since = datetime.now(timezone.utc) - timedelta(days=days - 1)
    since = since.replace(hour=0, minute=0, second=0, microsecond=0)
    rows = db.query(Execution).filter(Execution.organization_id == m.organization_id, Execution.created_at >= since).all()
    per_day: dict[str, dict] = defaultdict(lambda: {"runs": 0, "errors": 0, "tokens": 0})
    per_name: dict[str, dict] = defaultdict(lambda: {"runs": 0, "tokens": 0})
    durations = []
    for e in rows:
        created = e.created_at if e.created_at.tzinfo else e.created_at.replace(tzinfo=timezone.utc)
        day = created.strftime("%Y-%m-%d")
        per_day[day]["runs"] += 1
        per_day[day]["errors"] += 1 if e.status == "error" else 0
        per_day[day]["tokens"] += e.tokens_in + e.tokens_out
        key = f"{e.kind}:{e.name}"
        per_name[key]["runs"] += 1
        per_name[key]["tokens"] += e.tokens_in + e.tokens_out
        if e.status == "success":
            durations.append(e.duration_ms)
    series = []
    for i in range(days):
        d = (since + timedelta(days=i)).strftime("%Y-%m-%d")
        series.append({"date": d, **per_day.get(d, {"runs": 0, "errors": 0, "tokens": 0})})
    ok = sum(1 for e in rows if e.status == "success")
    top = sorted(({"name": k.split(":", 1)[1], "kind": k.split(":", 1)[0], **v} for k, v in per_name.items()), key=lambda x: x["runs"], reverse=True)[:5]
    return {
        "days": days,
        "agents": db.query(func.count(Agent.id)).filter(Agent.organization_id == m.organization_id).scalar() or 0,
        "workflows": db.query(func.count(Workflow.id)).filter(Workflow.organization_id == m.organization_id).scalar() or 0,
        "runs": len(rows),
        "success_rate": round(100 * ok / len(rows), 1) if rows else None,
        "tokens": sum(e.tokens_in + e.tokens_out for e in rows),
        "avg_duration_ms": int(sum(durations) / len(durations)) if durations else None,
        "series": series,
        "top": top,
    }
