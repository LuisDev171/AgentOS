import hashlib
import secrets
import uuid

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.crypto import encrypt_secret
from app.db import get_db
from app.dependencies import get_current_membership, require_manager
from app.models import ApiKey, Membership, ProviderCredential
from app.providers import PROVIDERS
from app.schemas import ApiKeyIn, ProviderKeyRequest
from app.tools import selectable_tools

router = APIRouter(tags=["Integrations"])


def hash_api_key(key: str) -> str:
    return hashlib.sha256(key.encode("utf-8")).hexdigest()


@router.get("/providers")
def list_providers(m: Membership = Depends(get_current_membership), db: Session = Depends(get_db)):
    creds = {c.provider: c for c in db.query(ProviderCredential).filter(ProviderCredential.organization_id == m.organization_id).all()}
    return [
        {"id": pid, "label": info["label"], "models": info["models"], "configured": pid in creds,
         "key_hint": creds[pid].key_hint if pid in creds else ""}
        for pid, info in PROVIDERS.items()
    ]


@router.put("/providers/{provider}/key", status_code=204)
def set_provider_key(provider: str, payload: ProviderKeyRequest, m: Membership = Depends(require_manager), db: Session = Depends(get_db)):
    if provider not in PROVIDERS:
        raise HTTPException(404, "Provedor desconhecido")
    key = payload.api_key.strip()
    cred = db.query(ProviderCredential).filter(ProviderCredential.organization_id == m.organization_id, ProviderCredential.provider == provider).first()
    if not cred:
        cred = ProviderCredential(organization_id=m.organization_id, provider=provider, api_key_encrypted="")
        db.add(cred)
    cred.api_key_encrypted = encrypt_secret(key)
    cred.key_hint = "…" + key[-4:]
    db.commit()


@router.delete("/providers/{provider}/key", status_code=204)
def delete_provider_key(provider: str, m: Membership = Depends(require_manager), db: Session = Depends(get_db)):
    db.query(ProviderCredential).filter(ProviderCredential.organization_id == m.organization_id, ProviderCredential.provider == provider).delete()
    db.commit()


@router.get("/tools")
def list_tools(m: Membership = Depends(get_current_membership)):
    return selectable_tools()


@router.get("/api-keys")
def list_api_keys(m: Membership = Depends(require_manager), db: Session = Depends(get_db)):
    rows = db.query(ApiKey).filter(ApiKey.organization_id == m.organization_id).order_by(ApiKey.created_at.desc()).all()
    return [{"id": r.id, "name": r.name, "prefix": r.prefix, "revoked": r.revoked, "last_used_at": r.last_used_at, "created_at": r.created_at} for r in rows]


@router.post("/api-keys", status_code=201)
def create_api_key(payload: ApiKeyIn, m: Membership = Depends(require_manager), db: Session = Depends(get_db)):
    key = "ak_" + secrets.token_urlsafe(32)
    row = ApiKey(organization_id=m.organization_id, name=payload.name.strip(), prefix=key[:10], key_hash=hash_api_key(key))
    db.add(row)
    db.commit()
    # A chave completa só é mostrada agora; depois só existe o hash.
    return {"id": row.id, "name": row.name, "prefix": row.prefix, "api_key": key}


@router.delete("/api-keys/{key_id}", status_code=204)
def revoke_api_key(key_id: uuid.UUID, m: Membership = Depends(require_manager), db: Session = Depends(get_db)):
    row = db.query(ApiKey).filter(ApiKey.id == key_id, ApiKey.organization_id == m.organization_id).first()
    if not row:
        raise HTTPException(404, "Chave não encontrada")
    row.revoked = True
    db.commit()
