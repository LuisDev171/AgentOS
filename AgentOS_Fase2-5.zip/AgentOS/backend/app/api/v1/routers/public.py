"""API pública: chama agentes e workflows de sistemas externos usando uma chave (header X-API-Key)."""
import time
import uuid
from collections import defaultdict, deque
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, Header, HTTPException
from sqlalchemy.orm import Session

from app.api.v1.routers.integrations import hash_api_key
from app.core.config import settings
from app.db import get_db
from app.models import Agent, ApiKey, Workflow
from app.runtime import execute_agent
from app.schemas import RunRequest
from app.workflows import execute_workflow

router = APIRouter(prefix="/public", tags=["Public API"])
_hits: dict[str, deque] = defaultdict(deque)


def api_key_auth(x_api_key: str | None = Header(default=None), db: Session = Depends(get_db)) -> ApiKey:
    if not x_api_key:
        raise HTTPException(401, "Envie a chave no header X-API-Key")
    row = db.query(ApiKey).filter(ApiKey.key_hash == hash_api_key(x_api_key.strip()), ApiKey.revoked == False).first()  # noqa: E712
    if not row:
        raise HTTPException(401, "Chave de API inválida")
    # limite simples por chave, em memória (por processo)
    now = time.monotonic()
    window = _hits[str(row.id)]
    while window and now - window[0] > 60:
        window.popleft()
    if len(window) >= settings.public_rate_limit_per_minute:
        raise HTTPException(429, "Muitas requisições. Tente novamente em instantes.")
    window.append(now)
    row.last_used_at = datetime.now(timezone.utc)
    db.commit()
    return row


@router.post("/agents/{agent_id}/run")
def run_agent(agent_id: uuid.UUID, payload: RunRequest, key: ApiKey = Depends(api_key_auth), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id, Agent.organization_id == key.organization_id, Agent.is_active == True).first()  # noqa: E712
    if not agent:
        raise HTTPException(404, "Agente não encontrado")
    if not payload.input.strip():
        raise HTTPException(422, "Campo 'input' obrigatório")
    text, ex = execute_agent(db, agent, payload.input, trigger="api")
    return {"output": text, "execution_id": ex.id, "tokens_in": ex.tokens_in, "tokens_out": ex.tokens_out}


@router.post("/workflows/{workflow_id}/run")
def run_workflow(workflow_id: uuid.UUID, payload: RunRequest, key: ApiKey = Depends(api_key_auth), db: Session = Depends(get_db)):
    wf = db.query(Workflow).filter(Workflow.id == workflow_id, Workflow.organization_id == key.organization_id, Workflow.is_active == True).first()  # noqa: E712
    if not wf:
        raise HTTPException(404, "Workflow não encontrado")
    output, ex = execute_workflow(db, wf, payload.input, trigger="api")
    return {"output": output, "execution_id": ex.id, "tokens_in": ex.tokens_in, "tokens_out": ex.tokens_out}
