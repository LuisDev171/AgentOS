"""Adaptadores OpenAI / Anthropic / Gemini com uma interface única.

Formato neutro de mensagens (o mesmo que é salvo no banco):
  {"role": "user", "content": "..."}
  {"role": "assistant", "content": "...", "tool_calls": [{"id", "name", "arguments": {...}}]}
  {"role": "tool", "tool_call_id": "...", "name": "...", "content": "..."}
"""
import json
import uuid
from dataclasses import dataclass, field
from typing import Callable

from app.core.config import settings

PROVIDERS = {
    "openai": {"label": "OpenAI", "models": ["gpt-4o-mini", "gpt-4o", "gpt-4.1-mini", "gpt-4.1"]},
    "anthropic": {"label": "Anthropic", "models": ["claude-haiku-5-5", "claude-sonnet-5-5", "claude-opus-5-5"]},
    "gemini": {"label": "Google Gemini", "models": ["gemini-2.5-flash", "gemini-2.5-pro", "gemini-2.0-flash"]},
}


class ProviderError(Exception):
    """Erro com mensagem segura para mostrar ao usuário (nunca contém a chave)."""


@dataclass
class ToolCall:
    id: str
    name: str
    arguments: dict


@dataclass
class LLMResult:
    text: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)
    tokens_in: int = 0
    tokens_out: int = 0


# http(url, headers, json_body) -> (status_code, parsed_json_or_text)
HttpPost = Callable[[str, dict, dict], tuple[int, object]]


def _default_http(url: str, headers: dict, body: dict) -> tuple[int, object]:
    import httpx

    try:
        response = httpx.post(url, headers=headers, json=body, timeout=settings.provider_timeout_seconds)
    except httpx.TimeoutException:
        raise ProviderError("O provedor de IA demorou demais para responder. Tente novamente.")
    except httpx.HTTPError:
        raise ProviderError("Não foi possível conectar ao provedor de IA. Verifique sua internet.")
    try:
        return response.status_code, response.json()
    except ValueError:
        return response.status_code, response.text


def _raise_for_status(provider: str, status: int, data: object) -> None:
    if 200 <= status < 300:
        return
    label = PROVIDERS[provider]["label"]
    detail = ""
    if isinstance(data, dict):
        err = data.get("error")
        if isinstance(err, dict):
            detail = str(err.get("message") or "")
        elif isinstance(err, str):
            detail = err
    if status in (401, 403):
        raise ProviderError(f"{label} recusou a chave de API (verifique se está correta e com permissão).")
    if status == 404:
        raise ProviderError(f"{label}: modelo não encontrado. Confira o nome do modelo do agente. {detail}".strip())
    if status == 429:
        raise ProviderError(f"{label}: limite de uso ou cota excedida. {detail}".strip())
    raise ProviderError(f"{label} retornou erro {status}. {detail}".strip()[:400])


def _json_args(value) -> dict:
    if isinstance(value, dict):
        return value
    try:
        parsed = json.loads(value or "{}")
        return parsed if isinstance(parsed, dict) else {}
    except (TypeError, ValueError):
        return {}


# ------------------------------------------------------------------ OpenAI ---
def _openai(model, api_key, system, messages, tools, temperature, max_tokens, http) -> LLMResult:
    out = []
    if system:
        out.append({"role": "system", "content": system})
    for m in messages:
        if m["role"] == "assistant":
            item = {"role": "assistant", "content": m.get("content") or None}
            if m.get("tool_calls"):
                item["tool_calls"] = [
                    {"id": c["id"], "type": "function", "function": {"name": c["name"], "arguments": json.dumps(c["arguments"], ensure_ascii=False)}}
                    for c in m["tool_calls"]
                ]
            out.append(item)
        elif m["role"] == "tool":
            out.append({"role": "tool", "tool_call_id": m["tool_call_id"], "content": m["content"]})
        else:
            out.append({"role": "user", "content": m["content"]})
    body = {"model": model, "messages": out, "max_completion_tokens": max_tokens}
    # Modelos de raciocínio (o1/o3/gpt-5...) só aceitam a temperatura padrão.
    if temperature is not None and not model.startswith(("o1", "o3", "o4", "gpt-5")):
        body["temperature"] = temperature
    if tools:
        body["tools"] = [{"type": "function", "function": {"name": t["name"], "description": t["description"], "parameters": t["parameters"]}} for t in tools]
    status, data = http("https://api.openai.com/v1/chat/completions", {"Authorization": f"Bearer {api_key}"}, body)
    _raise_for_status("openai", status, data)
    try:
        choice = data["choices"][0]["message"]
        calls = [
            ToolCall(c["id"], c["function"]["name"], _json_args(c["function"].get("arguments")))
            for c in (choice.get("tool_calls") or [])
        ]
        usage = data.get("usage") or {}
        return LLMResult(choice.get("content") or "", calls, usage.get("prompt_tokens", 0), usage.get("completion_tokens", 0))
    except (KeyError, IndexError, TypeError):
        raise ProviderError("Resposta inesperada da OpenAI.")


# --------------------------------------------------------------- Anthropic ---
def _anthropic(model, api_key, system, messages, tools, temperature, max_tokens, http) -> LLMResult:
    out: list[dict] = []
    for m in messages:
        if m["role"] == "assistant":
            blocks = []
            if m.get("content"):
                blocks.append({"type": "text", "text": m["content"]})
            for c in m.get("tool_calls") or []:
                blocks.append({"type": "tool_use", "id": c["id"], "name": c["name"], "input": c["arguments"]})
            out.append({"role": "assistant", "content": blocks or [{"type": "text", "text": "(sem resposta)"}]})
        elif m["role"] == "tool":
            block = {"type": "tool_result", "tool_use_id": m["tool_call_id"], "content": m["content"]}
            # resultados consecutivos precisam ir na mesma mensagem de usuário
            if out and out[-1]["role"] == "user" and isinstance(out[-1]["content"], list) and out[-1]["content"] and out[-1]["content"][0].get("type") == "tool_result":
                out[-1]["content"].append(block)
            else:
                out.append({"role": "user", "content": [block]})
        else:
            out.append({"role": "user", "content": m["content"]})
    body = {"model": model, "max_tokens": max_tokens, "messages": out}
    if system:
        body["system"] = system
    if temperature is not None:
        body["temperature"] = temperature
    if tools:
        body["tools"] = [{"name": t["name"], "description": t["description"], "input_schema": t["parameters"]} for t in tools]
    headers = {"x-api-key": api_key, "anthropic-version": "2023-06-01"}
    status, data = http("https://api.anthropic.com/v1/messages", headers, body)
    _raise_for_status("anthropic", status, data)
    try:
        text = "".join(b.get("text", "") for b in data["content"] if b.get("type") == "text")
        calls = [ToolCall(b["id"], b["name"], _json_args(b.get("input"))) for b in data["content"] if b.get("type") == "tool_use"]
        usage = data.get("usage") or {}
        return LLMResult(text, calls, usage.get("input_tokens", 0), usage.get("output_tokens", 0))
    except (KeyError, TypeError):
        raise ProviderError("Resposta inesperada da Anthropic.")


# ------------------------------------------------------------------ Gemini ---
def _gemini(model, api_key, system, messages, tools, temperature, max_tokens, http) -> LLMResult:
    contents: list[dict] = []
    for m in messages:
        if m["role"] == "assistant":
            parts = []
            if m.get("content"):
                parts.append({"text": m["content"]})
            for c in m.get("tool_calls") or []:
                parts.append({"functionCall": {"name": c["name"], "args": c["arguments"]}})
            contents.append({"role": "model", "parts": parts or [{"text": "(sem resposta)"}]})
        elif m["role"] == "tool":
            part = {"functionResponse": {"name": m.get("name") or "tool", "response": {"result": m["content"]}}}
            if contents and contents[-1]["role"] == "user" and contents[-1]["parts"] and "functionResponse" in contents[-1]["parts"][0]:
                contents[-1]["parts"].append(part)
            else:
                contents.append({"role": "user", "parts": [part]})
        else:
            contents.append({"role": "user", "parts": [{"text": m["content"]}]})
    body: dict = {"contents": contents, "generationConfig": {"maxOutputTokens": max_tokens}}
    if temperature is not None:
        body["generationConfig"]["temperature"] = temperature
    if system:
        body["systemInstruction"] = {"parts": [{"text": system}]}
    if tools:
        body["tools"] = [{"functionDeclarations": [{"name": t["name"], "description": t["description"], "parameters": t["parameters"]} for t in tools]}]
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
    status, data = http(url, {"x-goog-api-key": api_key}, body)
    _raise_for_status("gemini", status, data)
    try:
        candidates = data.get("candidates") or []
        if not candidates:
            reason = (data.get("promptFeedback") or {}).get("blockReason")
            raise ProviderError(f"Gemini não gerou resposta{' (bloqueado: ' + reason + ')' if reason else ''}.")
        parts = (candidates[0].get("content") or {}).get("parts") or []
        text = "".join(p.get("text", "") for p in parts if "text" in p)
        calls = [
            ToolCall(f"call_{uuid.uuid4().hex[:12]}", p["functionCall"]["name"], _json_args(p["functionCall"].get("args")))
            for p in parts if "functionCall" in p
        ]
        usage = data.get("usageMetadata") or {}
        return LLMResult(text, calls, usage.get("promptTokenCount", 0), usage.get("candidatesTokenCount", 0))
    except (KeyError, TypeError, AttributeError):
        raise ProviderError("Resposta inesperada do Gemini.")


_ADAPTERS = {"openai": _openai, "anthropic": _anthropic, "gemini": _gemini}


def chat(
    provider: str,
    model: str,
    api_key: str,
    system: str,
    messages: list[dict],
    tools: list[dict] | None = None,
    temperature: float | None = 0.7,
    max_tokens: int = 1024,
    http: HttpPost | None = None,
) -> LLMResult:
    adapter = _ADAPTERS.get(provider)
    if not adapter:
        raise ProviderError(f"Provedor desconhecido: {provider}")
    return adapter(model, api_key, system, messages, tools or [], temperature, max_tokens, http or _default_http)
