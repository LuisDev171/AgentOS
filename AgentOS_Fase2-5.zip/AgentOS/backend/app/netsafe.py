"""Proteção contra SSRF para requisições HTTP feitas a pedido de agentes/workflows."""
import ipaddress
import socket
from urllib.parse import urlparse


class UnsafeURL(ValueError):
    pass


def check_public_url(url: str) -> str:
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        raise UnsafeURL("Só são permitidas URLs http:// ou https://")
    host = parsed.hostname
    if not host:
        raise UnsafeURL("URL inválida")
    try:
        infos = socket.getaddrinfo(host, parsed.port or (443 if parsed.scheme == "https" else 80), proto=socket.IPPROTO_TCP)
    except socket.gaierror:
        raise UnsafeURL("Não foi possível resolver o endereço da URL")
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        if not ip.is_global:
            raise UnsafeURL("Endereços internos/privados não são permitidos")
    return url


def safe_request(method: str, url: str, *, body: str | None = None, headers: dict | None = None, timeout: float = 15.0, max_bytes: int = 200_000) -> tuple[int, str]:
    """Faz a requisição sem seguir redirecionamentos e limita o tamanho da resposta."""
    import httpx  # importado aqui para facilitar testes

    check_public_url(url)
    with httpx.Client(timeout=timeout, follow_redirects=False) as client:
        request = client.build_request(method.upper(), url, content=body.encode("utf-8") if body else None, headers=headers or {})
        response = client.send(request, stream=True)
        try:
            chunks, total = [], 0
            for chunk in response.iter_bytes():
                chunks.append(chunk)
                total += len(chunk)
                if total >= max_bytes:
                    break
            data = b"".join(chunks)[:max_bytes]
        finally:
            response.close()
    return response.status_code, data.decode("utf-8", errors="replace")
