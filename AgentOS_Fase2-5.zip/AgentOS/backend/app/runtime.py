"""Runtime de agentes: laço de chamada de modelo + ferramentas autorizadas + registro de execução."""
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone

from fastapi import HTTPException
from sqlalchemy import func
from sqlalchemy.orm import Session

from app import billing, providers
from app.core.config import settings
from app.crypto import decrypt_secret
from app.models import Agent, AgentKnowledge, Conversation, Execution, Message, ProviderCredential
from app.tools import TOOLS, ToolContext, run_tool, tool_specs

MAX_HISTORY_MESSAGES = 40


@dataclass
class AgentRun:
    text: str = ""
    new_messages: list[dict] = field(default_factory=list)
    tokens_in: int = 0
    tokens_out: int = 0
    trace: list[dict] = field(default_factory=list)


def _agent_kb_ids(db: Session, agent: Agent) -> list[uuid.UUID]:
    return [r.knowledge_base_id for r in db.query(AgentKnowledge).filter(AgentKnowledge.agent_id == agent.id).all()]


def _api_key(db: Session, agent: Agent) -> str:
    cred = db.query(ProviderCredential).filter(
        ProviderCredential.organization_id == agent.organization_id, ProviderCredential.provider == agent.provider
    ).first()
    if not cred:
        label = providers.PROVIDERS.get(agent.provider, {}).get("label", agent.provider)
        raise providers.ProviderError(f"Nenhuma chave de API cadastrada para {label}. Cadastre em Integrações > Provedores de IA.")
    try:
        return decrypt_secret(cred.api_key_encrypted)
    except ValueError as e:
        raise providers.ProviderError(str(e))


def run_agent_loop(db: Session, agent: Agent, user_input: str, history: list[dict] | None = None, http=None) -> AgentRun:
    """Executa o agente até ele responder em texto. Não grava nada no banco."""
    api_key = _api_key(db, agent)
    kb_ids = _agent_kb_ids(db, agent)
    allowed = [n for n in (agent.tools or []) if n in TOOLS and not TOOLS[n].automatic]
    if kb_ids:
        allowed.append("search_knowledge")
    specs = tool_specs(allowed)
    ctx = ToolContext(db=db, organization_id=agent.organization_id, kb_ids=kb_ids)

    system = agent.system_prompt or ""
    system += f"\n\nData e hora atuais (UTC): {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M')}."
    if kb_ids:
        system += "\nVocê tem acesso à base de conhecimento da empresa pela ferramenta search_knowledge; use-a antes de responder sobre documentos internos e diga quando não encontrar a informação."

    messages = list(history or [])
    first_new = len(messages)
    messages.append({"role": "user", "content": user_input})
    run = AgentRun()

    for step in range(settings.max_agent_steps):
        result = providers.chat(
            agent.provider, agent.model, api_key, system, messages, specs,
            temperature=agent.temperature, max_tokens=agent.max_tokens, http=http,
        )
        run.tokens_in += result.tokens_in
        run.tokens_out += result.tokens_out
        assistant = {"role": "assistant", "content": result.text}
        if result.tool_calls:
            assistant["tool_calls"] = [{"id": c.id, "name": c.name, "arguments": c.arguments} for c in result.tool_calls]
        messages.append(assistant)
        if not result.tool_calls:
            run.text = result.text
            break
        for call in result.tool_calls:
            if call.name in allowed:
                output = run_tool(call.name, call.arguments, ctx)
            else:
                output = f"Erro: a ferramenta '{call.name}' não está autorizada para este agente."
            run.trace.append({"tool": call.name, "arguments": call.arguments, "output": output[:500]})
            messages.append({"role": "tool", "tool_call_id": call.id, "name": call.name, "content": output})
    else:
        run.text = "Não consegui concluir: o limite de passos com ferramentas foi atingido."
        messages.append({"role": "assistant", "content": run.text})

    run.new_messages = messages[first_new:]
    return run


def load_history(db: Session, conversation: Conversation) -> list[dict]:
    rows = (
        db.query(Message).filter(Message.conversation_id == conversation.id)
        .order_by(Message.seq.desc()).limit(MAX_HISTORY_MESSAGES).all()
    )
    rows.reverse()
    while rows and rows[0].role != "user":  # não começar no meio de um ciclo de ferramenta
        rows.pop(0)
    history = []
    for r in rows:
        item = {"role": r.role, "content": r.content}
        if r.tool_calls:
            item["tool_calls"] = r.tool_calls
        if r.role == "tool":
            item["tool_call_id"] = r.tool_call_id
            item["name"] = r.tool_name
        history.append(item)
    return history


def save_messages(db: Session, conversation: Conversation, messages: list[dict]) -> None:
    seq = db.query(func.coalesce(func.max(Message.seq), 0)).filter(Message.conversation_id == conversation.id).scalar() or 0
    for m in messages:
        seq += 1
        db.add(Message(
            conversation_id=conversation.id, seq=seq, role=m["role"], content=m.get("content") or "",
            tool_calls=m.get("tool_calls"), tool_call_id=m.get("tool_call_id"), tool_name=m.get("name"),
        ))
    conversation.updated_at = datetime.now(timezone.utc)


def execute_agent(
    db: Session, agent: Agent, user_input: str, *, trigger: str = "manual",
    conversation: Conversation | None = None, http=None,
) -> tuple[str, Execution]:
    """Roda o agente, registra a execução e (opcionalmente) grava a conversa."""
    billing.ensure_can_run(db, agent.organization_id)
    execution = Execution(
        organization_id=agent.organization_id, kind="agent", agent_id=agent.id, name=agent.name,
        trigger=trigger, status="running", input_text=user_input[:20000],
    )
    db.add(execution)
    db.commit()
    started = time.monotonic()
    try:
        history = load_history(db, conversation) if conversation else []
        run = run_agent_loop(db, agent, user_input, history, http=http)
    except providers.ProviderError as e:
        _finish(db, execution, started, status="error", error=str(e))
        raise HTTPException(status_code=502, detail=str(e))
    except Exception:
        _finish(db, execution, started, status="error", error="Erro interno ao executar o agente.")
        raise HTTPException(status_code=500, detail="Erro interno ao executar o agente.")
    if conversation:
        save_messages(db, conversation, run.new_messages)
    _finish(db, execution, started, status="success", output=run.text, tokens_in=run.tokens_in, tokens_out=run.tokens_out, trace=run.trace)
    return run.text, execution


def _finish(db: Session, execution: Execution, started: float, *, status: str, output: str = "", error: str = "",
            tokens_in: int = 0, tokens_out: int = 0, trace: list | None = None) -> None:
    execution.status = status
    execution.output_text = output[:50000]
    execution.error = error
    execution.tokens_in = tokens_in
    execution.tokens_out = tokens_out
    execution.trace = trace or []
    execution.duration_ms = int((time.monotonic() - started) * 1000)
    db.commit()
