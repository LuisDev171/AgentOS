"""Workflows: sequência de passos (agente, texto com modelo, requisição HTTP) com variáveis."""
import json
import re
import time
import uuid

from fastapi import HTTPException
from sqlalchemy.orm import Session

from app import billing, providers, runtime
from app.models import Agent, Execution, Workflow
from app.netsafe import UnsafeURL, safe_request

STEP_TYPES = ("agent", "template", "http")
MAX_STEPS = 20
_ID_RE = re.compile(r"^[a-z][a-z0-9_]{0,31}$")
_VAR_RE = re.compile(r"\{\{\s*([a-zA-Z0-9_.]+)\s*\}\}")


def render(template: str, variables: dict) -> str:
    """Substitui {{input}}, {{last}} e {{steps.<id>.output}}."""
    def repl(match):
        value = variables.get(match.group(1))
        return "" if value is None else str(value)
    return _VAR_RE.sub(repl, template or "")


def validate_steps(db: Session, organization_id: uuid.UUID, steps: list[dict]) -> list[dict]:
    if not steps:
        raise HTTPException(422, "O workflow precisa de pelo menos um passo.")
    if len(steps) > MAX_STEPS:
        raise HTTPException(422, f"Máximo de {MAX_STEPS} passos.")
    seen, clean = set(), []
    for i, step in enumerate(steps, 1):
        sid, stype = str(step.get("id", "")), step.get("type")
        if not _ID_RE.match(sid):
            raise HTTPException(422, f"Passo {i}: o identificador deve começar com letra minúscula e usar só a-z, 0-9 e _.")
        if sid in seen:
            raise HTTPException(422, f"Passo {i}: identificador '{sid}' repetido.")
        seen.add(sid)
        if stype not in STEP_TYPES:
            raise HTTPException(422, f"Passo {i}: tipo inválido.")
        item = {"id": sid, "type": stype}
        if stype == "agent":
            try:
                agent_id = uuid.UUID(str(step.get("agent_id")))
            except ValueError:
                raise HTTPException(422, f"Passo {i}: escolha um agente.")
            if not db.query(Agent).filter(Agent.id == agent_id, Agent.organization_id == organization_id).first():
                raise HTTPException(422, f"Passo {i}: agente não encontrado.")
            item.update(agent_id=str(agent_id), prompt=str(step.get("prompt") or "{{last}}")[:8000])
        elif stype == "template":
            item.update(template=str(step.get("template") or "")[:8000])
        else:
            method = str(step.get("method") or "GET").upper()
            if method not in ("GET", "POST"):
                raise HTTPException(422, f"Passo {i}: método deve ser GET ou POST.")
            item.update(method=method, url=str(step.get("url") or "")[:2000], body=str(step.get("body") or "")[:8000])
            if not item["url"].startswith(("http://", "https://")) and "{{" not in item["url"]:
                raise HTTPException(422, f"Passo {i}: a URL deve começar com http:// ou https://.")
        clean.append(item)
    return clean


def execute_workflow(db: Session, workflow: Workflow, user_input: str, *, trigger: str = "manual", http=None) -> tuple[str, Execution]:
    billing.ensure_can_run(db, workflow.organization_id)
    execution = Execution(
        organization_id=workflow.organization_id, kind="workflow", workflow_id=workflow.id, name=workflow.name,
        trigger=trigger, status="running", input_text=user_input[:20000],
    )
    db.add(execution)
    db.commit()
    started = time.monotonic()
    variables: dict = {"input": user_input, "last": user_input}
    trace: list[dict] = []
    tokens_in = tokens_out = 0
    try:
        for step in workflow.steps:
            t0 = time.monotonic()
            entry = {"id": step["id"], "type": step["type"]}
            if step["type"] == "agent":
                agent = db.query(Agent).filter(Agent.id == uuid.UUID(step["agent_id"]), Agent.organization_id == workflow.organization_id).first()
                if not agent:
                    raise providers.ProviderError(f"Passo '{step['id']}': o agente foi removido.")
                prompt = render(step.get("prompt", "{{last}}"), variables)
                run = runtime.run_agent_loop(db, agent, prompt, http=http)
                output, tokens_in, tokens_out = run.text, tokens_in + run.tokens_in, tokens_out + run.tokens_out
                entry.update(agent=agent.name, tools=[t["tool"] for t in run.trace])
            elif step["type"] == "template":
                output = render(step.get("template", ""), variables)
            else:
                url = render(step["url"], variables).strip()
                body = render(step.get("body", ""), variables) or None
                headers = {"Content-Type": "application/json"} if body else {}
                try:
                    status, text = safe_request(step["method"], url, body=body, headers=headers)
                except UnsafeURL as e:
                    raise providers.ProviderError(f"Passo '{step['id']}': {e}")
                except Exception:
                    raise providers.ProviderError(f"Passo '{step['id']}': falha na requisição HTTP.")
                if status >= 400:
                    raise providers.ProviderError(f"Passo '{step['id']}': a requisição retornou HTTP {status}.")
                output = text
            variables[f"steps.{step['id']}.output"] = output
            variables["last"] = output
            entry.update(output=output[:1000], ms=int((time.monotonic() - t0) * 1000))
            trace.append(entry)
    except providers.ProviderError as e:
        runtime._finish(db, execution, started, status="error", error=str(e), tokens_in=tokens_in, tokens_out=tokens_out, trace=trace)
        raise HTTPException(status_code=502, detail=str(e))
    except Exception:
        runtime._finish(db, execution, started, status="error", error="Erro interno ao executar o workflow.", tokens_in=tokens_in, tokens_out=tokens_out, trace=trace)
        raise HTTPException(status_code=500, detail="Erro interno ao executar o workflow.")
    runtime._finish(db, execution, started, status="success", output=variables["last"], tokens_in=tokens_in, tokens_out=tokens_out, trace=trace)
    return variables["last"], execution
