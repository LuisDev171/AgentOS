"""Planos e limites de uso. O uso é calculado a partir das execuções do mês corrente (UTC).

ATENÇÃO: não há cobrança real — a troca de plano é apenas um registro interno até um
processador de pagamento (ex.: Stripe) ser integrado.
"""
import uuid
from datetime import datetime, timezone

from fastapi import HTTPException
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.models import Agent, Execution, Subscription, Workflow

PLANS = {
    "free": {"label": "Free", "price_brl": 0, "agents": 3, "workflows": 3, "runs_per_month": 100, "tokens_per_month": 100_000},
    "pro": {"label": "Pro", "price_brl": 149, "agents": 25, "workflows": 25, "runs_per_month": 5_000, "tokens_per_month": 5_000_000},
    "business": {"label": "Business", "price_brl": 599, "agents": 200, "workflows": 200, "runs_per_month": 100_000, "tokens_per_month": 100_000_000},
}


def month_start() -> datetime:
    now = datetime.now(timezone.utc)
    return datetime(now.year, now.month, 1, tzinfo=timezone.utc)


def get_plan_name(db: Session, organization_id: uuid.UUID) -> str:
    sub = db.query(Subscription).filter(Subscription.organization_id == organization_id).first()
    return sub.plan if sub and sub.plan in PLANS else "free"


def usage(db: Session, organization_id: uuid.UUID) -> dict:
    runs, tin, tout = db.query(
        func.count(Execution.id), func.coalesce(func.sum(Execution.tokens_in), 0), func.coalesce(func.sum(Execution.tokens_out), 0)
    ).filter(Execution.organization_id == organization_id, Execution.created_at >= month_start()).one()
    return {
        "runs": int(runs),
        "tokens": int(tin) + int(tout),
        "agents": db.query(func.count(Agent.id)).filter(Agent.organization_id == organization_id).scalar() or 0,
        "workflows": db.query(func.count(Workflow.id)).filter(Workflow.organization_id == organization_id).scalar() or 0,
    }


def ensure_can_create(db: Session, organization_id: uuid.UUID, resource: str) -> None:
    """resource: 'agents' | 'workflows'"""
    limits = PLANS[get_plan_name(db, organization_id)]
    if usage(db, organization_id)[resource] >= limits[resource]:
        raise HTTPException(status_code=402, detail=f"Limite do plano atingido ({limits[resource]} {resource}). Faça upgrade na aba Faturamento.")


def ensure_can_run(db: Session, organization_id: uuid.UUID) -> None:
    limits = PLANS[get_plan_name(db, organization_id)]
    u = usage(db, organization_id)
    if u["runs"] >= limits["runs_per_month"]:
        raise HTTPException(status_code=402, detail="Limite mensal de execuções do plano atingido. Faça upgrade na aba Faturamento.")
    if u["tokens"] >= limits["tokens_per_month"]:
        raise HTTPException(status_code=402, detail="Limite mensal de tokens do plano atingido. Faça upgrade na aba Faturamento.")
