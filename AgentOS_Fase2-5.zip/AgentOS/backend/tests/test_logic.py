"""Testes da lógica central (sem rede): adaptadores, ferramentas, runtime, knowledge e workflows.

Rodar:  cd backend && .venv\\Scripts\\python.exe -m pytest -q   (pip install pytest)
"""
import types
import pytest

from app import knowledge, providers, runtime, tools
from app.workflows import render


# ----------------------------------------------------------------- helpers ---
def make_http(responses):
    """Devolve (http, calls). `responses` é uma lista de (status, json) usada em ordem."""
    calls = []

    def http(url, headers, body):
        calls.append((url, headers, body))
        return responses[len(calls) - 1]
    return http, calls


TOOL = [{"name": "calculator", "description": "calc", "parameters": {"type": "object", "properties": {"expression": {"type": "string"}}}}]
HISTORY = [
    {"role": "user", "content": "quanto é 2+2?"},
    {"role": "assistant", "content": "", "tool_calls": [{"id": "c1", "name": "calculator", "arguments": {"expression": "2+2"}}]},
    {"role": "tool", "tool_call_id": "c1", "name": "calculator", "content": "4"},
]


# --------------------------------------------------------------- adaptadores --
def test_openai_request_and_parse():
    http, calls = make_http([(200, {"choices": [{"message": {"content": None, "tool_calls": [
        {"id": "x1", "type": "function", "function": {"name": "calculator", "arguments": '{"expression": "1+1"}'}}]}}],
        "usage": {"prompt_tokens": 10, "completion_tokens": 5}})])
    r = providers.chat("openai", "gpt-4o-mini", "KEY", "sys", HISTORY, TOOL, 0.5, 100, http)
    url, headers, body = calls[0]
    assert url.endswith("/chat/completions") and headers["Authorization"] == "Bearer KEY"
    assert body["messages"][0] == {"role": "system", "content": "sys"}
    assert body["messages"][3]["role"] == "tool" and body["messages"][3]["tool_call_id"] == "c1"
    assert body["tools"][0]["function"]["name"] == "calculator" and body["temperature"] == 0.5
    assert r.tool_calls[0].arguments == {"expression": "1+1"} and (r.tokens_in, r.tokens_out) == (10, 5)


def test_openai_reasoning_models_skip_temperature():
    http, calls = make_http([(200, {"choices": [{"message": {"content": "ok"}}], "usage": {}})])
    providers.chat("openai", "gpt-5-mini", "K", "", [{"role": "user", "content": "oi"}], None, 0.9, 50, http)
    assert "temperature" not in calls[0][2]


def test_anthropic_request_and_parse():
    http, calls = make_http([(200, {"content": [{"type": "text", "text": "Oi"}, {"type": "tool_use", "id": "t1", "name": "calculator", "input": {"expression": "3*3"}}],
                                     "usage": {"input_tokens": 7, "output_tokens": 3}})])
    r = providers.chat("anthropic", "claude-sonnet-5-5", "KEY", "sys", HISTORY, TOOL, 0.3, 100, http)
    url, headers, body = calls[0]
    assert url == "https://api.anthropic.com/v1/messages" and headers["x-api-key"] == "KEY" and body["system"] == "sys"
    assert body["messages"][1]["content"][0]["type"] == "tool_use"
    assert body["messages"][2] == {"role": "user", "content": [{"type": "tool_result", "tool_use_id": "c1", "content": "4"}]}
    assert body["tools"][0]["input_schema"]["type"] == "object"
    assert r.text == "Oi" and r.tool_calls[0].name == "calculator" and r.tokens_in == 7


def test_anthropic_merges_parallel_tool_results():
    msgs = [{"role": "user", "content": "x"},
            {"role": "assistant", "content": "", "tool_calls": [{"id": "a", "name": "calculator", "arguments": {}}, {"id": "b", "name": "calculator", "arguments": {}}]},
            {"role": "tool", "tool_call_id": "a", "name": "calculator", "content": "1"},
            {"role": "tool", "tool_call_id": "b", "name": "calculator", "content": "2"}]
    http, calls = make_http([(200, {"content": [{"type": "text", "text": "ok"}], "usage": {}})])
    providers.chat("anthropic", "m", "K", "", msgs, TOOL, 0.3, 50, http)
    assert len(calls[0][2]["messages"]) == 3 and len(calls[0][2]["messages"][2]["content"]) == 2


def test_gemini_request_and_parse():
    http, calls = make_http([(200, {"candidates": [{"content": {"parts": [{"text": "x"}, {"functionCall": {"name": "calculator", "args": {"expression": "5"}}}]}}],
                                     "usageMetadata": {"promptTokenCount": 4, "candidatesTokenCount": 2}})])
    r = providers.chat("gemini", "gemini-2.5-flash", "KEY", "sys", HISTORY, TOOL, 0.3, 100, http)
    url, headers, body = calls[0]
    assert url.endswith("/models/gemini-2.5-flash:generateContent") and headers["x-goog-api-key"] == "KEY"
    assert body["systemInstruction"]["parts"][0]["text"] == "sys"
    assert body["contents"][1]["role"] == "model" and body["contents"][2]["parts"][0]["functionResponse"]["name"] == "calculator"
    assert r.tool_calls[0].arguments == {"expression": "5"} and r.tool_calls[0].id.startswith("call_") and r.tokens_out == 2


@pytest.mark.parametrize("provider,status,expected", [("openai", 401, "recusou a chave"), ("anthropic", 404, "modelo não encontrado"), ("gemini", 429, "limite")])
def test_provider_errors_are_friendly_and_never_leak_key(provider, status, expected):
    http, _ = make_http([(status, {"error": {"message": "detalhe"}})])
    with pytest.raises(providers.ProviderError) as e:
        providers.chat(provider, "m", "SECRET-KEY-123", "", [{"role": "user", "content": "oi"}], None, 0.5, 50, http)
    assert expected in str(e.value) and "SECRET-KEY-123" not in str(e.value)


# ------------------------------------------------------------- ferramentas ---
CTX = tools.ToolContext(db=None, organization_id=None)


def test_calculator():
    run = lambda e: tools.run_tool("calculator", {"expression": e}, CTX)
    assert run("(12.5 * 3) / 2") == "18.75"
    assert run("2 ** 3 + 1") == "9"
    assert "divisão por zero" in run("1/0")
    assert "inválida" in run("__import__('os').system('echo hi')")
    assert "muito grande" not in run("2**10") and "inválida" in run("9**9**9")


def test_unknown_tool_and_selectable_list():
    assert "não existe" in tools.run_tool("rm_rf", {}, CTX)
    names = [t["name"] for t in tools.selectable_tools()]
    assert "calculator" in names and "search_knowledge" not in names  # automática


# --------------------------------------------------------------- knowledge ---
def test_chunking_and_search_ranking_ignores_accents():
    text = "\n\n".join(["Política de férias: funcionários têm 30 dias de férias por ano."] + ["Parágrafo de enchimento sobre outro assunto. " * 15] * 8 + ["O reembolso de despesas exige nota fiscal."])
    chunks = knowledge.split_into_chunks(text)
    assert len(chunks) > 1 and all(len(c) <= knowledge.CHUNK_SIZE + knowledge.CHUNK_OVERLAP + 4 for c in chunks)
    best = knowledge.bm25_rank("ferias", chunks, k=1)
    assert best and "férias" in chunks[best[0][0]]
    assert knowledge.bm25_rank("zzzz", chunks) == []


def test_giant_paragraph_is_split():
    chunks = knowledge.split_into_chunks("x" * 3000)
    assert len(chunks) >= 3 and all(len(c) <= knowledge.CHUNK_SIZE for c in chunks)


# ---------------------------------------------------------------- workflows ---
def test_render_variables():
    out = render("Resumo: {{ steps.a.output }} | entrada={{input}} | {{last}} | {{nada}}", {"input": "I", "last": "L", "steps.a.output": "A"})
    assert out == "Resumo: A | entrada=I | L | "


# ----------------------------------------------------------- runtime (laço) ---
def _agent(provider, tool_names):
    return types.SimpleNamespace(id="a1", organization_id="o1", provider=provider, model="m", system_prompt="Seja breve.",
                                 temperature=0.5, max_tokens=100, tools=tool_names)


@pytest.fixture
def rt(monkeypatch):
    monkeypatch.setattr(runtime, "_api_key", lambda db, agent: "KEY")
    monkeypatch.setattr(runtime, "_agent_kb_ids", lambda db, agent: [])


def test_agent_loop_runs_authorized_tool_then_answers(rt):
    http, calls = make_http([
        (200, {"choices": [{"message": {"content": "", "tool_calls": [{"id": "k1", "type": "function", "function": {"name": "calculator", "arguments": '{"expression": "6*7"}'}}]}}], "usage": {"prompt_tokens": 10, "completion_tokens": 2}}),
        (200, {"choices": [{"message": {"content": "A resposta é 42."}}], "usage": {"prompt_tokens": 20, "completion_tokens": 6}}),
    ])
    run = runtime.run_agent_loop(None, _agent("openai", ["calculator"]), "quanto é 6*7?", [], http=http)
    assert run.text == "A resposta é 42." and (run.tokens_in, run.tokens_out) == (30, 8)
    assert [m["role"] for m in run.new_messages] == ["user", "assistant", "tool", "assistant"]
    assert run.new_messages[2]["content"] == "42" and run.trace[0]["tool"] == "calculator"
    assert any(t["function"]["name"] == "calculator" for t in calls[0][2]["tools"])


def test_agent_loop_blocks_unauthorized_tool(rt):
    http, _ = make_http([
        (200, {"choices": [{"message": {"content": "", "tool_calls": [{"id": "k1", "type": "function", "function": {"name": "http_get", "arguments": '{"url": "http://x"}'}}]}}], "usage": {}}),
        (200, {"choices": [{"message": {"content": "Não posso."}}], "usage": {}}),
    ])
    run = runtime.run_agent_loop(None, _agent("openai", ["calculator"]), "acesse x", [], http=http)
    assert "não está autorizada" in run.new_messages[2]["content"]


def test_agent_loop_stops_after_max_steps(rt):
    loop = (200, {"choices": [{"message": {"content": "", "tool_calls": [{"id": "k", "type": "function", "function": {"name": "calculator", "arguments": '{"expression": "1"}'}}]}}], "usage": {}})
    http, calls = make_http([loop] * 50)
    run = runtime.run_agent_loop(None, _agent("openai", ["calculator"]), "x", [], http=http)
    assert len(calls) == runtime.settings.max_agent_steps and "limite de passos" in run.text
