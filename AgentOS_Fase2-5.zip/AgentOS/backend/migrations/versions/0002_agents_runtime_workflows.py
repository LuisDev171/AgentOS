"""Fases 2-5: agentes, conversas, knowledge base, workflows, execuções, chaves de API e planos.

As tabelas são criadas a partir dos modelos atuais (checkfirst), o que mantém esta migração
simples e segura para quem já criou as tabelas da Fase 1 via create_all em desenvolvimento.
"""
from alembic import op

revision = "0002_agents_runtime"
down_revision = "0001_initial"
branch_labels = None
depends_on = None

NEW_TABLES = [
    "provider_credentials", "agents", "knowledge_bases", "knowledge_documents", "knowledge_chunks",
    "agent_knowledge", "conversations", "messages", "workflows", "executions", "api_keys", "subscriptions",
]


def upgrade():
    from app import models  # noqa: F401
    from app.db import Base

    bind = op.get_bind()
    tables = [Base.metadata.tables[name] for name in NEW_TABLES]
    Base.metadata.create_all(bind=bind, tables=tables, checkfirst=True)


def downgrade():
    from app.db import Base

    bind = op.get_bind()
    for name in reversed(NEW_TABLES):
        Base.metadata.tables[name].drop(bind=bind, checkfirst=True)
