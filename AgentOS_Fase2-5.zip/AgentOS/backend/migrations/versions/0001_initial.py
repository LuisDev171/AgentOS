'''Initial AgentOS identity and organization tables.'''
from alembic import op
import sqlalchemy as sa

revision = '0001_initial'
down_revision = None
branch_labels = None
depends_on = None

def upgrade():
    op.create_table('organizations', sa.Column('id', sa.Uuid(), primary_key=True), sa.Column('name', sa.String(160), nullable=False), sa.Column('created_at', sa.DateTime(timezone=True), nullable=False))
    op.create_table('users', sa.Column('id', sa.Uuid(), primary_key=True), sa.Column('full_name', sa.String(160), nullable=False), sa.Column('email', sa.String(255), nullable=False), sa.Column('password_hash', sa.String(255)), sa.Column('google_sub', sa.String(255)), sa.Column('is_active', sa.Boolean(), nullable=False), sa.Column('two_factor_enabled', sa.Boolean(), nullable=False), sa.Column('two_factor_secret', sa.String(64)), sa.Column('created_at', sa.DateTime(timezone=True), nullable=False), sa.UniqueConstraint('google_sub'))
    op.create_index('ix_users_email', 'users', ['email'], unique=True)
    op.create_table('memberships', sa.Column('id', sa.Uuid(), primary_key=True), sa.Column('organization_id', sa.Uuid(), sa.ForeignKey('organizations.id', ondelete='CASCADE'), nullable=False), sa.Column('user_id', sa.Uuid(), sa.ForeignKey('users.id', ondelete='CASCADE'), nullable=False), sa.Column('role', sa.String(32), nullable=False), sa.Column('created_at', sa.DateTime(timezone=True), nullable=False), sa.UniqueConstraint('organization_id', 'user_id', name='uq_membership_org_user'))
    op.create_index('ix_memberships_organization_id', 'memberships', ['organization_id'])
    op.create_index('ix_memberships_user_id', 'memberships', ['user_id'])

def downgrade():
    op.drop_index('ix_memberships_user_id', table_name='memberships')
    op.drop_index('ix_memberships_organization_id', table_name='memberships')
    op.drop_table('memberships')
    op.drop_index('ix_users_email', table_name='users')
    op.drop_table('users')
    op.drop_table('organizations')
