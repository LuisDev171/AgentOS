import { useEffect, useState } from "react";
import { Activity, BookOpen, Bot, Building2, ChevronDown, CreditCard, LayoutDashboard, LogOut, Network, Plug, ShieldCheck, Workflow } from "lucide-react";
import type { Ctx, Page } from "./ui";
import Overview from "./pages/Overview";
import Agents from "./pages/Agents";
import Workflows from "./pages/Workflows";
import Knowledge from "./pages/Knowledge";
import Executions from "./pages/Executions";
import Integrations from "./pages/Integrations";
import BillingPage from "./pages/Billing";
import Security from "./pages/Security";

type User = { id: string; full_name: string; email: string; two_factor_enabled: boolean };
type Organization = { id: string; name: string; role: string };

const NAV: { id: Page; label: string; icon: React.ReactNode }[] = [
  { id: "overview", label: "Overview", icon: <LayoutDashboard size={17} /> },
  { id: "agents", label: "My Agents", icon: <Bot size={17} /> },
  { id: "workflows", label: "Workflows", icon: <Workflow size={17} /> },
  { id: "knowledge", label: "Knowledge Base", icon: <BookOpen size={17} /> },
  { id: "executions", label: "Executions", icon: <Activity size={17} /> },
  { id: "integrations", label: "Integrations", icon: <Plug size={17} /> },
];
const WORKSPACE_NAV: { id: Page; label: string; icon: React.ReactNode }[] = [
  { id: "billing", label: "Billing & Usage", icon: <CreditCard size={17} /> },
  { id: "security", label: "Security", icon: <ShieldCheck size={17} /> },
];
const ALL = [...NAV, ...WORKSPACE_NAV];

function pageFromHash(): Page {
  const h = window.location.hash.replace("#", "") as Page;
  return ALL.some(n => n.id === h) ? h : "overview";
}

export default function Shell({ user, organization, onLogout, onUser }: { user: User; organization: Organization; onLogout: () => void; onUser: (u: User) => void }) {
  const [page, setPage] = useState<Page>(pageFromHash());
  useEffect(() => {
    const on = () => setPage(pageFromHash());
    window.addEventListener("hashchange", on);
    return () => window.removeEventListener("hashchange", on);
  }, []);
  const go = (p: Page) => { window.location.hash = p; setPage(p); };
  const ctx: Ctx = { role: organization.role, canManage: ["owner", "admin"].includes(organization.role), go };
  const current = ALL.find(n => n.id === page)!;

  const link = (n: { id: Page; label: string; icon: React.ReactNode }) => (
    <a key={n.id} className={page === n.id ? "selected" : ""} onClick={() => go(n.id)} role="button" tabIndex={0} onKeyDown={e => e.key === "Enter" && go(n.id)}>{n.icon} {n.label}</a>
  );

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand"><div className="brand-mark"><Network size={22} /></div><div><b>AgentOS</b><small>WORKSPACE</small></div></div>
        <div className="workspace"><div className="workspace-icon"><Building2 size={17} /></div><div><b>{organization.name}</b><small>{organization.role.toUpperCase()}</small></div><ChevronDown size={15} /></div>
        <div className="nav-label">PLATFORM</div>
        <nav>{NAV.map(link)}</nav>
        <div className="nav-label team-label">WORKSPACE</div>
        <nav>{WORKSPACE_NAV.map(link)}</nav>
        <div className="sidebar-bottom">
          <div className="profile"><div className="avatar">{user.full_name.slice(0, 1).toUpperCase()}</div><div className="profile-info"><b>{user.full_name}</b><small>{user.email}</small></div><button title="Sair" onClick={onLogout}><LogOut size={17} /></button></div>
        </div>
      </aside>
      <main className="main-content">
        <header className="topbar"><div><span className="breadcrumb">Workspace</span><span className="crumb-divider">/</span><b>{current.label}</b></div><div className="top-actions"><span className="status-pill"><i /> System operational</span><div className="avatar">{user.full_name.slice(0, 1).toUpperCase()}</div></div></header>
        {page === "overview" && <Overview ctx={ctx} name={user.full_name.split(" ")[0]} />}
        {page === "agents" && <Agents ctx={ctx} />}
        {page === "workflows" && <Workflows ctx={ctx} />}
        {page === "knowledge" && <Knowledge ctx={ctx} />}
        {page === "executions" && <Executions />}
        {page === "integrations" && <Integrations ctx={ctx} />}
        {page === "billing" && <BillingPage ctx={ctx} />}
        {page === "security" && <Security user={user} onUser={onUser} />}
        <footer>© 2026 AgentOS · Intelligence Orchestration Platform <span>v0.2.0</span></footer>
      </main>
    </div>
  );
}
