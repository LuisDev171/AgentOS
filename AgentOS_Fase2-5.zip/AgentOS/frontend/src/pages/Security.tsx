import { useState } from "react";
import { Fingerprint } from "lucide-react";
import { api } from "../api";
import { Banner, errMsg, PageHeader } from "../ui";

type User = { id: string; full_name: string; email: string; two_factor_enabled: boolean };

export default function Security({ user, onUser }: { user: User; onUser: (u: User) => void }) {
  const [qr, setQr] = useState("");
  const [secret, setSecret] = useState("");
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  async function enable() {
    setError(""); setNotice("");
    try {
      const r = await api<{ qr_code_data_url: string; secret: string }>("/auth/2fa/setup", { method: "POST" });
      setQr(r.qr_code_data_url); setSecret(r.secret);
    } catch (e) { setError(errMsg(e)); }
  }

  async function confirm(ev: React.FormEvent) {
    ev.preventDefault(); setError("");
    try {
      await api("/auth/2fa/confirm", { method: "POST", body: JSON.stringify({ code }) });
      setNotice("Autenticação em dois fatores ativada."); setQr(""); setCode("");
      onUser(await api<User>("/auth/me"));
    } catch (e) { setError(errMsg(e)); }
  }

  return (
    <div className="page">
      <PageHeader eyebrow="WORKSPACE" title="Segurança" subtitle="Proteja o acesso à sua conta." />
      <section className="panel narrow">
        <div className="panel-heading"><div><h2><Fingerprint size={17} /> Autenticação em dois fatores</h2><p>Use um aplicativo autenticador (Google Authenticator, Authy, 1Password…).</p></div><span className="tag">{user.two_factor_enabled ? "Ativada" : "Desativada"}</span></div>
        {!user.two_factor_enabled && !qr && <button className="primary-btn compact" onClick={enable}>Configurar 2FA</button>}
        {qr && (
          <div className="qr-panel">
            <h3>Configure seu autenticador</h3>
            <p>Escaneie o QR code e guarde o segredo em local seguro.</p>
            <img src={qr} alt="QR code de autenticação" /><code>{secret}</code>
            <form onSubmit={confirm}><input aria-label="Código 2FA" placeholder="Código de 6 dígitos" value={code} onChange={e => setCode(e.target.value)} maxLength={8} /><button className="primary-btn compact">Confirmar 2FA</button></form>
          </div>
        )}
        <Banner error={error} notice={notice} />
      </section>
    </div>
  );
}
