import { useEffect, useState } from "react";
import { KeyRound, Trash2 } from "lucide-react";
import { api } from "../api";
import { Banner, Ctx, Empty, errMsg, fmtDate, PageHeader } from "../ui";

type Provider = { id: string; label: string; configured: boolean; key_hint: string };
type ApiKey = { id: string; name: string; prefix: string; revoked: boolean; last_used_at: string | null; created_at: string };

export default function Integrations({ ctx }: { ctx: Ctx }) {
  const [providers, setProviders] = useState<Provider[]>([]);
  const [keys, setKeys] = useState<ApiKey[]>([]);
  const [inputs, setInputs] = useState<Record<string, string>>({});
  const [name, setName] = useState("");
  const [created, setCreated] = useState("");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  const load = () => {
    api<Provider[]>("/providers").then(setProviders).catch(e => setError(errMsg(e)));
    if (ctx.canManage) api<ApiKey[]>("/api-keys").then(setKeys).catch(e => setError(errMsg(e)));
  };
  useEffect(load, []);

  async function saveKey(id: string) {
    setError(""); setNotice("");
    try { await api(`/providers/${id}/key`, { method: "PUT", body: JSON.stringify({ api_key: inputs[id] ?? "" }) }); setInputs({ ...inputs, [id]: "" }); setNotice("Chave salva (criptografada)."); load(); }
    catch (e) { setError(errMsg(e)); }
  }
  async function removeKey(id: string) {
    if (!confirm("Remover a chave deste provedor? Agentes que o usam deixarão de funcionar.")) return;
    try { await api(`/providers/${id}/key`, { method: "DELETE" }); load(); } catch (e) { setError(errMsg(e)); }
  }
  async function createApiKey(ev: React.FormEvent) {
    ev.preventDefault(); setError(""); setCreated("");
    try { const r = await api<{ api_key: string }>("/api-keys", { method: "POST", body: JSON.stringify({ name }) }); setCreated(r.api_key); setName(""); load(); }
    catch (e) { setError(errMsg(e)); }
  }
  async function revoke(id: string) {
    if (!confirm("Revogar esta chave? Sistemas que a usam perderão o acesso.")) return;
    try { await api(`/api-keys/${id}`, { method: "DELETE" }); load(); } catch (e) { setError(errMsg(e)); }
  }

  const apiBase = (import.meta.env.VITE_API_URL || "http://localhost:8000/api/v1");

  return (
    <div className="page">
      <PageHeader eyebrow="INTEGRATIONS" title="Integrações" subtitle="Conecte provedores de IA e libere acesso externo por API." />
      <Banner error={error} notice={notice} />
      <section className="panel">
        <div className="panel-heading"><div><h2>Provedores de IA</h2><p>As chaves ficam criptografadas no servidor e nunca são exibidas novamente.</p></div></div>
        {providers.map(p => (
          <div key={p.id} className="provider-row">
            <div><b>{p.label}</b><small>{p.configured ? `Chave cadastrada ${p.key_hint}` : "Sem chave"}</small></div>
            {ctx.canManage ? <div className="row grow">
              <input type="password" autoComplete="off" placeholder={p.configured ? "Substituir chave…" : "Cole a chave de API"} value={inputs[p.id] ?? ""} onChange={e => setInputs({ ...inputs, [p.id]: e.target.value })} />
              <button className="primary-btn compact" disabled={(inputs[p.id] ?? "").length < 8} onClick={() => saveKey(p.id)}>Salvar</button>
              {p.configured && <button className="icon-btn" title="Remover chave" onClick={() => removeKey(p.id)}><Trash2 size={15} /></button>}
            </div> : <span className={`tag ${p.configured ? "success" : ""}`}>{p.configured ? "configurado" : "pendente"}</span>}
          </div>
        ))}
      </section>
      {ctx.canManage && (
        <section className="panel">
          <div className="panel-heading"><div><h2><KeyRound size={17} /> Chaves de API do AgentOS</h2><p>Permitem que outros sistemas executem seus agentes e workflows.</p></div></div>
          <form className="mini-form" onSubmit={createApiKey}><input required minLength={2} placeholder="Nome da chave (ex.: Site, CRM)" value={name} onChange={e => setName(e.target.value)} /><button className="primary-btn compact">Gerar chave</button></form>
          {created && <div className="alert success">Copie agora — ela não será mostrada de novo:<code className="secret">{created}</code></div>}
          {keys.length === 0 ? <Empty>Nenhuma chave criada.</Empty> : (
            <table className="table"><tbody>{keys.map(k => (
              <tr key={k.id}><td>{k.name}</td><td><code>{k.prefix}…</code></td><td>Último uso: {fmtDate(k.last_used_at)}</td><td>{k.revoked ? <span className="tag error">revogada</span> : <button className="btn-ghost" onClick={() => revoke(k.id)}>Revogar</button>}</td></tr>
            ))}</tbody></table>
          )}
          <h3 className="sub">Como usar</h3>
          <pre className="snippet">{`curl -X POST ${apiBase}/public/agents/ID_DO_AGENTE/run \\
  -H "X-API-Key: SUA_CHAVE" -H "Content-Type: application/json" \\
  -d '{"input": "Olá!"}'

# Workflows: ${apiBase}/public/workflows/ID_DO_WORKFLOW/run`}</pre>
        </section>
      )}
    </div>
  );
}
