import { useEffect, useState } from "react";
import { BookOpen, FileText, Plus, Search, Trash2 } from "lucide-react";
import { api } from "../api";
import { Banner, Ctx, Empty, errMsg, Field, fmtDate, fmtNum, PageHeader } from "../ui";

type KB = { id: string; name: string; description: string; documents: number };
type Doc = { id: string; title: string; char_count: number; chunk_count: number; created_at: string };

export default function Knowledge({ ctx }: { ctx: Ctx }) {
  const [kbs, setKbs] = useState<KB[]>([]);
  const [sel, setSel] = useState<KB | null>(null);
  const [docs, setDocs] = useState<Doc[]>([]);
  const [newKb, setNewKb] = useState({ name: "", description: "" });
  const [doc, setDoc] = useState({ title: "", content: "" });
  const [q, setQ] = useState("");
  const [results, setResults] = useState<{ score: number; text: string }[] | null>(null);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  const loadKbs = () => api<KB[]>("/knowledge-bases").then(setKbs).catch(e => setError(errMsg(e)));
  const loadDocs = (id: string) => api<Doc[]>(`/knowledge-bases/${id}/documents`).then(setDocs).catch(e => setError(errMsg(e)));
  useEffect(() => { loadKbs(); }, []);
  useEffect(() => { setResults(null); if (sel) loadDocs(sel.id); else setDocs([]); }, [sel?.id]);

  async function createKb(ev: React.FormEvent) {
    ev.preventDefault(); setError(""); setNotice("");
    try { const kb = await api<KB>("/knowledge-bases", { method: "POST", body: JSON.stringify(newKb) }); setNewKb({ name: "", description: "" }); await loadKbs(); setSel(kb); }
    catch (e) { setError(errMsg(e)); }
  }
  async function removeKb() {
    if (!sel || !confirm(`Excluir a base "${sel.name}" e todos os documentos?`)) return;
    try { await api(`/knowledge-bases/${sel.id}`, { method: "DELETE" }); setSel(null); loadKbs(); } catch (e) { setError(errMsg(e)); }
  }
  async function addDoc(ev: React.FormEvent) {
    ev.preventDefault(); if (!sel) return; setError(""); setNotice("");
    try {
      await api(`/knowledge-bases/${sel.id}/documents`, { method: "POST", body: JSON.stringify(doc) });
      setDoc({ title: "", content: "" }); setNotice("Documento adicionado e indexado."); loadDocs(sel.id); loadKbs();
    } catch (e) { setError(errMsg(e)); }
  }
  async function removeDoc(id: string) {
    if (!sel) return;
    try { await api(`/knowledge-bases/${sel.id}/documents/${id}`, { method: "DELETE" }); loadDocs(sel.id); loadKbs(); } catch (e) { setError(errMsg(e)); }
  }
  async function readFile(file?: File) {
    if (!file) return;
    if (file.size > 500_000) { setError("Arquivo muito grande (máx. ~500 KB de texto)."); return; }
    const content = await file.text();
    setDoc({ title: doc.title || file.name.replace(/\.[^.]+$/, ""), content });
  }
  async function search(ev: React.FormEvent) {
    ev.preventDefault(); if (!sel || !q.trim()) return;
    try { setResults(await api(`/knowledge-bases/${sel.id}/search?q=${encodeURIComponent(q)}`)); } catch (e) { setError(errMsg(e)); }
  }

  return (
    <div className="page">
      <PageHeader eyebrow="KNOWLEDGE BASE" title="Base de conhecimento" subtitle="Documentos que os agentes consultam para responder com informações da sua empresa." />
      <Banner error={error} notice={notice} />
      <div className="split">
        <section className="panel list-panel">
          {kbs.length === 0 && <Empty>Nenhuma base criada.</Empty>}
          {kbs.map(k => (
            <button key={k.id} className={`list-item ${sel?.id === k.id ? "active" : ""}`} onClick={() => setSel(k)}>
              <span className="li-icon"><BookOpen size={16} /></span><span><b>{k.name}</b><small>{k.documents} documento(s)</small></span>
            </button>
          ))}
          {ctx.canManage && (
            <form className="mini-form" onSubmit={createKb}>
              <input required minLength={2} placeholder="Nome da nova base" value={newKb.name} onChange={e => setNewKb({ ...newKb, name: e.target.value })} />
              <button className="primary-btn compact"><Plus size={15} /> Criar</button>
            </form>
          )}
        </section>
        {sel ? (
          <div className="stack">
            <section className="panel">
              <div className="panel-heading"><div><h2>{sel.name}</h2><p>Para usar, marque esta base no agente (Agent Studio).</p></div>{ctx.canManage && <button className="btn-danger" onClick={removeKb}><Trash2 size={15} /> Excluir base</button>}</div>
              {docs.length === 0 ? <Empty>Sem documentos. Adicione abaixo.</Empty> : (
                <table className="table"><tbody>{docs.map(d => (
                  <tr key={d.id}><td><FileText size={14} /> {d.title}</td><td className="num">{fmtNum(d.char_count)} car.</td><td className="num">{d.chunk_count} trechos</td><td className="num">{fmtDate(d.created_at)}</td>
                    <td>{ctx.canManage && <button className="icon-btn" title="Remover" onClick={() => removeDoc(d.id)}><Trash2 size={15} /></button>}</td></tr>
                ))}</tbody></table>
              )}
            </section>
            {ctx.canManage && (
              <section className="panel">
                <div className="panel-heading"><div><h2>Adicionar documento</h2><p>Cole o texto ou carregue um arquivo .txt, .md, .csv ou .json. (PDF ainda não é suportado.)</p></div></div>
                <form className="form-grid" onSubmit={addDoc}>
                  <Field label="Título"><input required value={doc.title} onChange={e => setDoc({ ...doc, title: e.target.value })} /></Field>
                  <Field label="Arquivo de texto"><input type="file" accept=".txt,.md,.csv,.json,text/*" onChange={e => readFile(e.target.files?.[0])} /></Field>
                  <div className="span-2"><Field label="Conteúdo"><textarea required rows={8} value={doc.content} onChange={e => setDoc({ ...doc, content: e.target.value })} /></Field></div>
                  <div className="actions span-2"><button className="primary-btn compact">Indexar documento</button></div>
                </form>
              </section>
            )}
            <section className="panel">
              <div className="panel-heading"><div><h2>Testar busca</h2><p>Veja quais trechos seriam encontrados.</p></div></div>
              <form className="mini-form" onSubmit={search}><input placeholder="Pergunta ou palavras-chave" value={q} onChange={e => setQ(e.target.value)} /><button className="primary-btn compact"><Search size={15} /> Buscar</button></form>
              {results && (results.length === 0 ? <Empty>Nada encontrado.</Empty> : results.map((r, i) => <pre key={i} className="snippet">{r.text}</pre>))}
            </section>
          </div>
        ) : <section className="panel"><Empty>Selecione uma base ou crie uma nova.</Empty></section>}
      </div>
    </div>
  );
}
