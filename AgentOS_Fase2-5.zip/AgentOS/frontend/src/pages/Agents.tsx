import { useEffect, useRef, useState } from "react";
import { Bot, Plus, Send, Trash2, Wrench } from "lucide-react";
import { api } from "../api";
import { Banner, Ctx, Empty, errMsg, Field, fmtDate, PageHeader } from "../ui";

type Agent = {
  id: string; name: string; description: string; provider: string; model: string; system_prompt: string;
  temperature: number; max_tokens: number; tools: string[]; knowledge_base_ids: string[]; is_active: boolean;
};
type Provider = { id: string; label: string; models: string[]; configured: boolean };
type Tool = { name: string; label: string; description: string };
type KB = { id: string; name: string };
type Conv = { id: string; title: string; updated_at: string };
type Msg = { role: "user" | "assistant" | "tool_use"; content: string; tools?: string[]; meta?: string };

const blank = (provider = "openai", model = "gpt-4o-mini"): Agent => ({
  id: "", name: "", description: "", provider, model, system_prompt: "Você é um assistente prestativo e objetivo. Responda em português.",
  temperature: 0.7, max_tokens: 1024, tools: [], knowledge_base_ids: [], is_active: true,
});

export default function Agents({ ctx }: { ctx: Ctx }) {
  const [agents, setAgents] = useState<Agent[]>([]);
  const [providers, setProviders] = useState<Provider[]>([]);
  const [tools, setTools] = useState<Tool[]>([]);
  const [kbs, setKbs] = useState<KB[]>([]);
  const [draft, setDraft] = useState<Agent | null>(null);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  async function load() {
    try {
      const [a, p, t, k] = await Promise.all([api<Agent[]>("/agents"), api<Provider[]>("/providers"), api<Tool[]>("/tools"), api<KB[]>("/knowledge-bases")]);
      setAgents(a); setProviders(p); setTools(t); setKbs(k);
    } catch (e) { setError(errMsg(e)); }
  }
  useEffect(() => { load(); }, []);

  function startNew() {
    const first = providers.find(p => p.configured) ?? providers[0];
    setDraft(blank(first?.id, first?.models[0]));
    setError(""); setNotice("");
  }

  async function save(ev: React.FormEvent) {
    ev.preventDefault();
    if (!draft) return;
    setError(""); setNotice("");
    const { id, ...body } = draft;
    try {
      const saved = await api<Agent>(id ? `/agents/${id}` : "/agents", { method: id ? "PUT" : "POST", body: JSON.stringify(body) });
      setDraft(saved); setNotice("Agente salvo."); load();
    } catch (e) { setError(errMsg(e)); }
  }

  async function remove() {
    if (!draft?.id || !confirm(`Excluir o agente "${draft.name}" e suas conversas?`)) return;
    try { await api(`/agents/${draft.id}`, { method: "DELETE" }); setDraft(null); load(); }
    catch (e) { setError(errMsg(e)); }
  }

  const set = <K extends keyof Agent>(k: K, v: Agent[K]) => setDraft(d => (d ? { ...d, [k]: v } : d));
  const toggle = (k: "tools" | "knowledge_base_ids", v: string) =>
    setDraft(d => (d ? { ...d, [k]: d[k].includes(v) ? d[k].filter(x => x !== v) : [...d[k], v] } : d));
  const provider = providers.find(p => p.id === draft?.provider);

  return (
    <div className="page">
      <PageHeader eyebrow="AGENT STUDIO" title="Meus agentes" subtitle="Crie agentes, escolha o modelo e teste conversas."
        action={ctx.canManage ? <button className="primary-btn compact" onClick={startNew}><Plus size={17} /> Novo agente</button> : undefined} />
      <Banner error={error} notice={notice} />
      <div className="split">
        <section className="panel list-panel">
          {agents.length === 0 && <Empty>Nenhum agente ainda.{ctx.canManage ? " Clique em “Novo agente”." : ""}</Empty>}
          {agents.map(a => (
            <button key={a.id} className={`list-item ${draft?.id === a.id ? "active" : ""}`} onClick={() => { setDraft(a); setError(""); setNotice(""); }}>
              <span className="li-icon"><Bot size={16} /></span>
              <span><b>{a.name}</b><small>{a.provider} · {a.model}{a.is_active ? "" : " · desativado"}</small></span>
            </button>
          ))}
        </section>
        {draft ? (
          <div className="stack">
            <section className="panel">
              <div className="panel-heading"><div><h2>{draft.id ? "Editar agente" : "Novo agente"}</h2></div></div>
              <form className="form-grid" onSubmit={save}>
                <Field label="Nome"><input required minLength={2} value={draft.name} onChange={e => set("name", e.target.value)} placeholder="Ex.: Atendente de suporte" disabled={!ctx.canManage} /></Field>
                <Field label="Descrição"><input value={draft.description} onChange={e => set("description", e.target.value)} placeholder="Para que serve" disabled={!ctx.canManage} /></Field>
                <Field label="Provedor" hint={provider && !provider.configured ? "Sem chave cadastrada — cadastre em Integrações." : undefined}>
                  <select value={draft.provider} onChange={e => { const p = providers.find(x => x.id === e.target.value); set("provider", e.target.value); if (p) set("model", p.models[0]); }} disabled={!ctx.canManage}>
                    {providers.map(p => <option key={p.id} value={p.id}>{p.label}{p.configured ? "" : " (sem chave)"}</option>)}
                  </select>
                </Field>
                <Field label="Modelo" hint="Escolha da lista ou digite o nome exato do modelo.">
                  <input list="model-list" required value={draft.model} onChange={e => set("model", e.target.value)} disabled={!ctx.canManage} />
                  <datalist id="model-list">{provider?.models.map(m => <option key={m} value={m} />)}</datalist>
                </Field>
                <div className="span-2"><Field label="Instruções (system prompt)"><textarea rows={5} value={draft.system_prompt} onChange={e => set("system_prompt", e.target.value)} disabled={!ctx.canManage} /></Field></div>
                <Field label={`Criatividade (temperatura): ${draft.temperature}`}><input type="range" min={0} max={1.5} step={0.1} value={draft.temperature} onChange={e => set("temperature", Number(e.target.value))} disabled={!ctx.canManage} /></Field>
                <Field label="Máx. de tokens na resposta"><input type="number" min={16} max={8192} value={draft.max_tokens} onChange={e => set("max_tokens", Number(e.target.value))} disabled={!ctx.canManage} /></Field>
                <div className="span-2">
                  <span className="label-text"><Wrench size={13} /> Ferramentas autorizadas</span>
                  <div className="checks">{tools.map(t => (
                    <label key={t.name} className="check" title={t.description}><input type="checkbox" checked={draft.tools.includes(t.name)} onChange={() => toggle("tools", t.name)} disabled={!ctx.canManage} /> {t.label}</label>
                  ))}</div>
                </div>
                <div className="span-2">
                  <span className="label-text">Bases de conhecimento</span>
                  {kbs.length === 0 ? <small className="muted-text">Nenhuma base criada. Crie em Knowledge Base.</small> :
                    <div className="checks">{kbs.map(k => <label key={k.id} className="check"><input type="checkbox" checked={draft.knowledge_base_ids.includes(k.id)} onChange={() => toggle("knowledge_base_ids", k.id)} disabled={!ctx.canManage} /> {k.name}</label>)}</div>}
                </div>
                <label className="check span-2"><input type="checkbox" checked={draft.is_active} onChange={e => set("is_active", e.target.checked)} disabled={!ctx.canManage} /> Agente ativo</label>
                {ctx.canManage && (
                  <div className="actions span-2">
                    <button className="primary-btn compact">Salvar agente</button>
                    {draft.id && <button type="button" className="btn-danger" onClick={remove}><Trash2 size={15} /> Excluir</button>}
                  </div>
                )}
              </form>
            </section>
            {draft.id && <Playground agent={draft} onError={setError} />}
          </div>
        ) : <section className="panel"><Empty>Selecione um agente na lista ou crie um novo.</Empty></section>}
      </div>
    </div>
  );
}

function Playground({ agent, onError }: { agent: Agent; onError: (m: string) => void }) {
  const [convs, setConvs] = useState<Conv[]>([]);
  const [convId, setConvId] = useState<string>("");
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const end = useRef<HTMLDivElement>(null);

  const loadConvs = () => api<Conv[]>(`/agents/${agent.id}/conversations`).then(setConvs).catch(() => undefined);
  useEffect(() => { setConvId(""); setMsgs([]); loadConvs(); }, [agent.id]);
  useEffect(() => { end.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs, busy]);

  async function open(id: string) {
    setConvId(id);
    if (!id) { setMsgs([]); return; }
    try { setMsgs(await api<Msg[]>(`/conversations/${id}/messages`)); } catch (e) { onError(errMsg(e)); }
  }

  async function send(ev: React.FormEvent) {
    ev.preventDefault();
    const message = text.trim();
    if (!message || busy) return;
    setText(""); setBusy(true); onError("");
    setMsgs(m => [...m, { role: "user", content: message }]);
    try {
      const r = await api<{ conversation_id: string; reply: string; tokens_in: number; tokens_out: number; tools_used: string[] }>(
        `/agents/${agent.id}/chat`, { method: "POST", body: JSON.stringify({ message, conversation_id: convId || null }) });
      setConvId(r.conversation_id);
      setMsgs(m => [...m, { role: "assistant", content: r.reply || "(resposta vazia)", tools: r.tools_used, meta: `${r.tokens_in + r.tokens_out} tokens` }]);
      loadConvs();
    } catch (e) { onError(errMsg(e)); }
    finally { setBusy(false); }
  }

  async function removeConv() {
    if (!convId || !confirm("Excluir esta conversa?")) return;
    await api(`/conversations/${convId}`, { method: "DELETE" }).catch(e => onError(errMsg(e)));
    setConvId(""); setMsgs([]); loadConvs();
  }

  return (
    <section className="panel">
      <div className="panel-heading">
        <div><h2>Playground</h2><p>Teste {agent.name} com o modelo salvo. Salve o agente antes de testar mudanças.</p></div>
        <div className="actions">
          <select value={convId} onChange={e => open(e.target.value)}>
            <option value="">Nova conversa</option>
            {convs.map(c => <option key={c.id} value={c.id}>{c.title} · {fmtDate(c.updated_at)}</option>)}
          </select>
          {convId && <button className="icon-btn" title="Excluir conversa" onClick={removeConv}><Trash2 size={16} /></button>}
        </div>
      </div>
      <div className="chat">
        {msgs.length === 0 && <Empty>Envie uma mensagem para começar.</Empty>}
        {msgs.map((m, i) => m.role === "tool_use"
          ? <div key={i} className="tool-note"><Wrench size={12} /> usou: {m.content}</div>
          : <div key={i} className={`bubble ${m.role}`}>{m.content}{m.role === "assistant" && (m.tools?.length || m.meta) ? <small>{m.tools?.length ? `ferramentas: ${m.tools.join(", ")} · ` : ""}{m.meta}</small> : null}</div>)}
        {busy && <div className="bubble assistant typing">Pensando…</div>}
        <div ref={end} />
      </div>
      <form className="chat-input" onSubmit={send}>
        <input value={text} onChange={e => setText(e.target.value)} placeholder="Escreva sua mensagem…" disabled={busy} />
        <button className="primary-btn compact" disabled={busy || !text.trim()}><Send size={16} /> Enviar</button>
      </form>
    </section>
  );
}
