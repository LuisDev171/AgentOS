import { useEffect, useState } from "react";
import { api } from "../api";
import { Banner, Empty, errMsg, fmtDate, fmtNum, PageHeader } from "../ui";

type Row = { id: string; kind: string; name: string; trigger: string; status: string; tokens_in: number; tokens_out: number; duration_ms: number; created_at: string };
type Detail = Row & { input: string; output: string; error: string; trace: Record<string, unknown>[] };

export default function Executions() {
  const [rows, setRows] = useState<Row[]>([]);
  const [total, setTotal] = useState(0);
  const [kind, setKind] = useState("");
  const [status, setStatus] = useState("");
  const [detail, setDetail] = useState<Detail | null>(null);
  const [error, setError] = useState("");

  const load = () => {
    const p = new URLSearchParams({ limit: "100" });
    if (kind) p.set("kind", kind);
    if (status) p.set("status", status);
    api<{ total: number; items: Row[] }>(`/executions?${p}`).then(r => { setRows(r.items); setTotal(r.total); }).catch(e => setError(errMsg(e)));
  };
  useEffect(load, [kind, status]);

  async function open(id: string) {
    try { setDetail(await api<Detail>(`/executions/${id}`)); } catch (e) { setError(errMsg(e)); }
  }

  return (
    <div className="page">
      <PageHeader eyebrow="EXECUTIONS" title="Execuções" subtitle={`${fmtNum(total)} registro(s). Cada conversa ou workflow executado fica registrado aqui.`}
        action={<div className="actions">
          <select value={kind} onChange={e => setKind(e.target.value)}><option value="">Todos os tipos</option><option value="agent">Agentes</option><option value="workflow">Workflows</option></select>
          <select value={status} onChange={e => setStatus(e.target.value)}><option value="">Todos os status</option><option value="success">Sucesso</option><option value="error">Erro</option><option value="running">Em andamento</option></select>
        </div>} />
      <Banner error={error} />
      <div className="split wide-right">
        <section className="panel">
          {rows.length === 0 ? <Empty>Nenhuma execução ainda.</Empty> : (
            <table className="table clickable"><thead><tr><th>Quando</th><th>Nome</th><th>Origem</th><th>Status</th><th className="num">Tokens</th><th className="num">Tempo</th></tr></thead>
              <tbody>{rows.map(r => (
                <tr key={r.id} onClick={() => open(r.id)} className={detail?.id === r.id ? "sel" : ""}>
                  <td>{fmtDate(r.created_at)}</td><td>{r.name} <span className="tag">{r.kind === "agent" ? "agente" : "workflow"}</span></td><td>{r.trigger === "api" ? "API" : "manual"}</td>
                  <td><span className={`tag ${r.status}`}>{r.status === "success" ? "sucesso" : r.status === "error" ? "erro" : "rodando"}</span></td>
                  <td className="num">{fmtNum(r.tokens_in + r.tokens_out)}</td><td className="num">{(r.duration_ms / 1000).toFixed(1)} s</td>
                </tr>))}</tbody></table>
          )}
        </section>
        <section className="panel">
          {!detail ? <Empty>Clique em uma execução para ver os detalhes.</Empty> : <>
            <div className="panel-heading"><div><h2>{detail.name}</h2><p>{fmtDate(detail.created_at)} · {detail.tokens_in} entrada / {detail.tokens_out} saída</p></div></div>
            {detail.error && <div className="alert error">{detail.error}</div>}
            <h3 className="sub">Entrada</h3><pre className="snippet">{detail.input || "—"}</pre>
            <h3 className="sub">Saída</h3><pre className="snippet">{detail.output || "—"}</pre>
            {detail.trace.length > 0 && <><h3 className="sub">Rastro (ferramentas / passos)</h3><pre className="snippet">{JSON.stringify(detail.trace, null, 2)}</pre></>}
          </>}
        </section>
      </div>
    </div>
  );
}
