import { useEffect, useState } from "react";
import { ArrowDown, ArrowUp, Play, Plus, Trash2, Workflow as WorkflowIcon } from "lucide-react";
import { api } from "../api";
import { Banner, Ctx, Empty, errMsg, Field, PageHeader } from "../ui";

type Step = { id: string; type: "agent" | "template" | "http"; agent_id?: string; prompt?: string; template?: string; method?: string; url?: string; body?: string };
type Wf = { id: string; name: string; description: string; steps: Step[]; is_active: boolean };
type Agent = { id: string; name: string };
type RunResult = { output: string; tokens_in: number; tokens_out: number; trace: { id: string; type: string; output: string; ms: number }[] };

const blank = (): Wf => ({ id: "", name: "", description: "", is_active: true, steps: [{ id: "passo1", type: "agent", prompt: "{{input}}" }] });
const TYPE_LABEL = { agent: "Agente de IA", template: "Texto / formatação", http: "Requisição HTTP" };

export default function Workflows({ ctx }: { ctx: Ctx }) {
  const [list, setList] = useState<Wf[]>([]);
  const [agents, setAgents] = useState<Agent[]>([]);
  const [draft, setDraft] = useState<Wf | null>(null);
  const [input, setInput] = useState("");
  const [result, setResult] = useState<RunResult | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  async function load() {
    try { const [w, a] = await Promise.all([api<Wf[]>("/workflows"), api<Agent[]>("/agents")]); setList(w); setAgents(a); }
    catch (e) { setError(errMsg(e)); }
  }
  useEffect(() => { load(); }, []);

  const setStep = (i: number, patch: Partial<Step>) => setDraft(d => d && { ...d, steps: d.steps.map((s, j) => (j === i ? { ...s, ...patch } : s)) });
  const move = (i: number, dir: -1 | 1) => setDraft(d => {
    if (!d) return d; const j = i + dir; if (j < 0 || j >= d.steps.length) return d;
    const steps = [...d.steps]; [steps[i], steps[j]] = [steps[j], steps[i]]; return { ...d, steps };
  });
  const addStep = () => setDraft(d => {
    if (!d) return d;
    let n = d.steps.length + 1; while (d.steps.some(s => s.id === `passo${n}`)) n++;
    return { ...d, steps: [...d.steps, { id: `passo${n}`, type: "agent", prompt: "{{last}}" }] };
  });

  async function save(ev: React.FormEvent) {
    ev.preventDefault(); if (!draft) return; setError(""); setNotice("");
    const { id, ...body } = draft;
    try {
      const saved = await api<Wf>(id ? `/workflows/${id}` : "/workflows", { method: id ? "PUT" : "POST", body: JSON.stringify(body) });
      setDraft(saved); setNotice("Workflow salvo."); load();
    } catch (e) { setError(errMsg(e)); }
  }
  async function remove() {
    if (!draft?.id || !confirm(`Excluir o workflow "${draft.name}"?`)) return;
    try { await api(`/workflows/${draft.id}`, { method: "DELETE" }); setDraft(null); load(); } catch (e) { setError(errMsg(e)); }
  }
  async function run() {
    if (!draft?.id) return; setBusy(true); setError(""); setResult(null);
    try { setResult(await api<RunResult>(`/workflows/${draft.id}/run`, { method: "POST", body: JSON.stringify({ input }) })); }
    catch (e) { setError(errMsg(e)); } finally { setBusy(false); }
  }

  return (
    <div className="page">
      <PageHeader eyebrow="WORKFLOW BUILDER" title="Workflows" subtitle="Encadeie passos: cada passo recebe o resultado dos anteriores."
        action={ctx.canManage ? <button className="primary-btn compact" onClick={() => { setDraft(blank()); setResult(null); setError(""); setNotice(""); }}><Plus size={17} /> Novo workflow</button> : undefined} />
      <Banner error={error} notice={notice} />
      <div className="split">
        <section className="panel list-panel">
          {list.length === 0 && <Empty>Nenhum workflow ainda.</Empty>}
          {list.map(w => (
            <button key={w.id} className={`list-item ${draft?.id === w.id ? "active" : ""}`} onClick={() => { setDraft(w); setResult(null); setError(""); setNotice(""); }}>
              <span className="li-icon"><WorkflowIcon size={16} /></span><span><b>{w.name}</b><small>{w.steps.length} passo(s){w.is_active ? "" : " · desativado"}</small></span>
            </button>
          ))}
        </section>
        {draft ? (
          <div className="stack">
            <section className="panel">
              <form className="form-grid" onSubmit={save}>
                <Field label="Nome"><input required minLength={2} value={draft.name} onChange={e => setDraft({ ...draft, name: e.target.value })} disabled={!ctx.canManage} /></Field>
                <Field label="Descrição"><input value={draft.description} onChange={e => setDraft({ ...draft, description: e.target.value })} disabled={!ctx.canManage} /></Field>
                <div className="span-2 hint-box">Variáveis nos textos: <code>{"{{input}}"}</code> (entrada do workflow), <code>{"{{last}}"}</code> (saída do passo anterior) e <code>{"{{steps.ID.output}}"}</code> (saída de um passo específico).</div>
                {draft.steps.map((s, i) => (
                  <div key={i} className="step span-2">
                    <div className="step-head">
                      <b>{i + 1}</b>
                      <input className="step-id" value={s.id} onChange={e => setStep(i, { id: e.target.value })} aria-label="Identificador do passo" disabled={!ctx.canManage} />
                      <select value={s.type} onChange={e => setStep(i, { type: e.target.value as Step["type"] })} disabled={!ctx.canManage}>
                        {Object.entries(TYPE_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                      </select>
                      {ctx.canManage && <span className="step-actions">
                        <button type="button" className="icon-btn" onClick={() => move(i, -1)} title="Subir"><ArrowUp size={14} /></button>
                        <button type="button" className="icon-btn" onClick={() => move(i, 1)} title="Descer"><ArrowDown size={14} /></button>
                        <button type="button" className="icon-btn" onClick={() => setDraft({ ...draft, steps: draft.steps.filter((_, j) => j !== i) })} title="Remover"><Trash2 size={14} /></button>
                      </span>}
                    </div>
                    {s.type === "agent" && <>
                      <select required value={s.agent_id ?? ""} onChange={e => setStep(i, { agent_id: e.target.value })} disabled={!ctx.canManage}>
                        <option value="">Escolha um agente…</option>{agents.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                      </select>
                      <textarea rows={3} placeholder="Mensagem enviada ao agente" value={s.prompt ?? ""} onChange={e => setStep(i, { prompt: e.target.value })} disabled={!ctx.canManage} />
                    </>}
                    {s.type === "template" && <textarea rows={3} placeholder="Texto de saída, ex.: Resumo:\n{{last}}" value={s.template ?? ""} onChange={e => setStep(i, { template: e.target.value })} disabled={!ctx.canManage} />}
                    {s.type === "http" && <>
                      <div className="row"><select value={s.method ?? "GET"} onChange={e => setStep(i, { method: e.target.value })} disabled={!ctx.canManage}><option>GET</option><option>POST</option></select>
                        <input placeholder="https://api.exemplo.com/..." value={s.url ?? ""} onChange={e => setStep(i, { url: e.target.value })} disabled={!ctx.canManage} /></div>
                      {s.method === "POST" && <textarea rows={3} placeholder='Corpo (JSON), ex.: {"texto": "{{last}}"}' value={s.body ?? ""} onChange={e => setStep(i, { body: e.target.value })} disabled={!ctx.canManage} />}
                    </>}
                  </div>
                ))}
                {ctx.canManage && <div className="span-2"><button type="button" className="btn-ghost" onClick={addStep}><Plus size={15} /> Adicionar passo</button></div>}
                <label className="check span-2"><input type="checkbox" checked={draft.is_active} onChange={e => setDraft({ ...draft, is_active: e.target.checked })} disabled={!ctx.canManage} /> Workflow ativo</label>
                {ctx.canManage && <div className="actions span-2"><button className="primary-btn compact">Salvar workflow</button>{draft.id && <button type="button" className="btn-danger" onClick={remove}><Trash2 size={15} /> Excluir</button>}</div>}
              </form>
            </section>
            {draft.id && (
              <section className="panel">
                <div className="panel-heading"><div><h2>Executar</h2><p>Salve antes de executar para usar as últimas alterações.</p></div></div>
                <Field label="Entrada ({{input}})"><textarea rows={3} value={input} onChange={e => setInput(e.target.value)} /></Field>
                <div className="actions"><button className="primary-btn compact" disabled={busy} onClick={run}><Play size={15} /> {busy ? "Executando…" : "Executar workflow"}</button></div>
                {result && <div className="result">
                  <h3 className="sub">Resultado final · {result.tokens_in + result.tokens_out} tokens</h3><pre className="snippet">{result.output || "(vazio)"}</pre>
                  <h3 className="sub">Passos</h3>{result.trace.map(t => <div key={t.id} className="trace-row"><b>{t.id}</b> <span className="tag">{t.type}</span> <small>{t.ms} ms</small><pre className="snippet">{t.output}</pre></div>)}
                </div>}
              </section>
            )}
          </div>
        ) : <section className="panel"><Empty>Selecione um workflow ou crie um novo.</Empty></section>}
      </div>
    </div>
  );
}
