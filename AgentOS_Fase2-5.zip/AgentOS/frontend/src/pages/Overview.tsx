import { useEffect, useState } from "react";
import { Activity, Bot, Check, Workflow, Zap } from "lucide-react";
import { api } from "../api";
import { Banner, Ctx, errMsg, fmtNum, PageHeader } from "../ui";

type Metrics = {
  days: number; agents: number; workflows: number; runs: number; success_rate: number | null; tokens: number; avg_duration_ms: number | null;
  series: { date: string; runs: number; errors: number; tokens: number }[];
  top: { name: string; kind: string; runs: number; tokens: number }[];
};
type Provider = { id: string; configured: boolean };

export default function Overview({ ctx, name }: { ctx: Ctx; name: string }) {
  const [m, setM] = useState<Metrics | null>(null);
  const [providers, setProviders] = useState<Provider[]>([]);
  const [error, setError] = useState("");

  useEffect(() => {
    Promise.all([api<Metrics>("/metrics/overview?days=14"), api<Provider[]>("/providers")])
      .then(([metrics, provs]) => { setM(metrics); setProviders(provs); })
      .catch(e => setError(errMsg(e)));
  }, []);

  const max = Math.max(1, ...(m?.series.map(s => s.runs) ?? [1]));
  const hasProvider = providers.some(p => p.configured);
  const steps = [
    { done: hasProvider, title: "Conectar um provedor de IA", text: "Cadastre a chave da OpenAI, Anthropic ou Gemini.", page: "integrations" as const },
    { done: (m?.agents ?? 0) > 0, title: "Criar seu primeiro agente", text: "Defina modelo, instruções e ferramentas.", page: "agents" as const },
    { done: (m?.runs ?? 0) > 0, title: "Fazer a primeira execução", text: "Converse com o agente no Playground.", page: "agents" as const },
    { done: (m?.workflows ?? 0) > 0, title: "Montar um workflow", text: "Encadeie agentes e ações em passos.", page: "workflows" as const },
  ];

  return (
    <div className="page">
      <PageHeader eyebrow="WORKSPACE OVERVIEW" title={`Bem-vindo, ${name}.`} subtitle="Visão geral dos últimos 14 dias." />
      <Banner error={error} />
      <div className="metrics">
        <Stat icon={<Bot />} label="Agentes" value={m ? fmtNum(m.agents) : "…"} note="Criados no workspace" />
        <Stat icon={<Workflow />} label="Workflows" value={m ? fmtNum(m.workflows) : "…"} note="Automações montadas" />
        <Stat icon={<Zap />} label="Execuções" value={m ? fmtNum(m.runs) : "…"} note={m?.success_rate != null ? `${m.success_rate}% de sucesso` : "Nenhuma ainda"} />
        <Stat icon={<Activity />} label="Tokens usados" value={m ? fmtNum(m.tokens) : "…"} note={m?.avg_duration_ms != null ? `Média de ${(m.avg_duration_ms / 1000).toFixed(1)} s` : "—"} />
      </div>
      <div className="content-grid">
        <section className="panel">
          <div className="panel-heading"><div><h2>Execuções por dia</h2><p>Últimos 14 dias.</p></div></div>
          <div className="bars">
            {m?.series.map(s => (
              <div key={s.date} className="bar-col" title={`${s.date}: ${s.runs} execuções, ${s.errors} com erro`}>
                <div className="bar-track"><div className="bar" style={{ height: `${(s.runs / max) * 100}%` }}>{s.errors > 0 && <i style={{ height: `${(s.errors / Math.max(s.runs, 1)) * 100}%` }} />}</div></div>
                <small>{s.date.slice(8)}</small>
              </div>
            ))}
          </div>
          {m && m.top.length > 0 && <>
            <h3 className="sub">Mais usados</h3>
            <table className="table"><tbody>{m.top.map(t => <tr key={t.kind + t.name}><td>{t.name}</td><td><span className="tag">{t.kind === "agent" ? "agente" : "workflow"}</span></td><td className="num">{t.runs} exec.</td><td className="num">{fmtNum(t.tokens)} tokens</td></tr>)}</tbody></table>
          </>}
        </section>
        <section className="panel">
          <div className="panel-heading"><div><h2>Primeiros passos</h2><p>Coloque o workspace para trabalhar.</p></div></div>
          <div className="checklist">
            {steps.map((s, i) => (
              <div key={s.title} className={`check-item ${s.done ? "done" : ""}`}>
                <span>{s.done ? <Check size={15} /> : i + 1}</span>
                <div><b>{s.title}</b><small>{s.text}</small></div>
                {s.done ? <em>Concluído</em> : <button onClick={() => ctx.go(s.page)}>Abrir</button>}
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}

function Stat({ icon, label, value, note }: { icon: React.ReactNode; label: string; value: string; note: string }) {
  return <div className="metric-card"><div className="metric-top"><span className="metric-icon">{icon}</span></div><small>{label}</small><strong>{value}</strong><p>{note}</p></div>;
}
