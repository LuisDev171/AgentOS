import { useEffect, useState } from "react";
import { api } from "../api";
import { Banner, Ctx, errMsg, fmtNum, PageHeader } from "../ui";

type PlanInfo = { id: string; label: string; price_brl: number; agents: number; workflows: number; runs_per_month: number; tokens_per_month: number };
type Billing = { plan: string; limits: PlanInfo; usage: { runs: number; tokens: number; agents: number; workflows: number }; plans: PlanInfo[]; payments_enabled: boolean };

export default function BillingPage({ ctx }: { ctx: Ctx }) {
  const [b, setB] = useState<Billing | null>(null);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const load = () => api<Billing>("/billing").then(setB).catch(e => setError(errMsg(e)));
  useEffect(() => { load(); }, []);

  async function change(plan: string) {
    setError(""); setNotice("");
    try { await api("/billing/plan", { method: "POST", body: JSON.stringify({ plan }) }); setNotice("Plano atualizado."); load(); }
    catch (e) { setError(errMsg(e)); }
  }

  const meter = (label: string, used: number, limit: number) => {
    const pct = Math.min(100, (used / limit) * 100);
    return <div className="meter"><div className="meter-top"><span>{label}</span><b>{fmtNum(used)} / {fmtNum(limit)}</b></div><div className="meter-track"><span className={pct >= 90 ? "hot" : ""} style={{ width: `${pct}%` }} /></div></div>;
  };

  return (
    <div className="page">
      <PageHeader eyebrow="BILLING" title="Faturamento e uso" subtitle="Consumo do mês corrente (UTC) e limites do plano." />
      <Banner error={error} notice={notice} />
      {b && <>
        <section className="panel">
          <div className="panel-heading"><div><h2>Plano atual: {b.limits.label}</h2><p>O uso é contado a partir do dia 1º de cada mês.</p></div></div>
          {meter("Execuções no mês", b.usage.runs, b.limits.runs_per_month)}
          {meter("Tokens no mês", b.usage.tokens, b.limits.tokens_per_month)}
          {meter("Agentes", b.usage.agents, b.limits.agents)}
          {meter("Workflows", b.usage.workflows, b.limits.workflows)}
        </section>
        <div className="plans">
          {b.plans.map(p => (
            <section key={p.id} className={`panel plan ${p.id === b.plan ? "current" : ""}`}>
              <h2>{p.label}</h2><strong>{p.price_brl === 0 ? "Grátis" : `R$ ${p.price_brl}/mês`}</strong>
              <ul><li>{fmtNum(p.agents)} agentes</li><li>{fmtNum(p.workflows)} workflows</li><li>{fmtNum(p.runs_per_month)} execuções/mês</li><li>{fmtNum(p.tokens_per_month)} tokens/mês</li></ul>
              {p.id === b.plan ? <span className="tag success">Plano atual</span> : <button className="primary-btn compact" disabled={ctx.role !== "owner"} onClick={() => change(p.id)}>Escolher</button>}
            </section>
          ))}
        </div>
        {!b.payments_enabled && <div className="hint-box">Pagamentos ainda não estão integrados: a troca de plano apenas altera os limites, sem cobrança. Os custos de uso dos provedores de IA são cobrados por eles, na sua conta.</div>}
      </>}
    </div>
  );
}
