const API = import.meta.env.VITE_API_URL || "http://localhost:8000/api/v1";

export function getToken() {
  return sessionStorage.getItem("agentos_token");
}
export function setToken(token: string) {
  sessionStorage.setItem("agentos_token", token);
}
export function clearToken() {
  sessionStorage.removeItem("agentos_token");
}

export async function api<T>(path: string, options: RequestInit = {}, token?: string): Promise<T> {
  const headers = new Headers(options.headers);
  if (options.body && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
  const activeToken = token || getToken();
  if (activeToken) headers.set("Authorization", `Bearer ${activeToken}`);
  const response = await fetch(`${API}${path}`, { ...options, headers });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.detail || "Não foi possível concluir a solicitação");
  return data as T;
}

export function googleLoginUrl() {
  return `${API}/auth/google/login`;
}
