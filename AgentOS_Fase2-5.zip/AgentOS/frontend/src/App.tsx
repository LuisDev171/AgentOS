import { useEffect, useState } from "react";
import { ArrowRight, Bot, Cpu, Network, ShieldCheck, Sparkles, Workflow } from "lucide-react";
import { api, clearToken, getToken, googleLoginUrl, setToken } from "./api";
import Shell from "./Shell";

type AuthResult = { access_token: string; token_type: string; requires_2fa?: boolean };
type User = { id: string; full_name: string; email: string; two_factor_enabled: boolean };
type Organization = { id: string; name: string; role: string };

export default function App() {
  const [token, setTokenState] = useState(getToken());
  const [user, setUser] = useState<User | null>(null);
  const [organization, setOrganization] = useState<Organization | null>(null);
  const [mode, setMode] = useState<"login" | "register" | "mfa">("login");
  const [challenge, setChallenge] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [code, setCode] = useState("");
  const [form, setForm] = useState({ full_name: "", email: "", password: "", organization_name: "" });

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const oauthToken = params.get("token");
    const mfaToken = params.get("mfa_token");
    if (window.location.pathname === "/oauth/callback" && mfaToken) {
      setChallenge(mfaToken);
      setMode("mfa");
      setNotice("Login Google concluído. Informe seu código de autenticação em dois fatores.");
      window.history.replaceState({}, "", "/");
    } else if (window.location.pathname === "/oauth/callback" && oauthToken) {
      setToken(oauthToken);
      setTokenState(oauthToken);
      window.history.replaceState({}, "", "/");
    }
  }, []);

  useEffect(() => {
    if (!token) return;
    Promise.all([
      api<User>("/auth/me", {}, token),
      api<Organization>("/organizations/current", {}, token)
    ]).then(([u, o]) => { setUser(u); setOrganization(o); })
      .catch(() => { clearToken(); setTokenState(null); setUser(null); });
  }, [token]);

  function update(field: keyof typeof form, value: string) {
    setForm(current => ({ ...current, [field]: value }));
  }

  async function submitAuth(event: React.FormEvent) {
    event.preventDefault(); setLoading(true); setError(""); setNotice("");
    try {
      const path = mode === "register" ? "/auth/register" : "/auth/login";
      const body = mode === "register" ? form : { email: form.email, password: form.password };
      const result = await api<AuthResult>(path, { method: "POST", body: JSON.stringify(body) });
      if (result.requires_2fa) {
        setChallenge(result.access_token); setMode("mfa"); setNotice("Informe o código do seu aplicativo autenticador."); return;
      }
      setToken(result.access_token); setTokenState(result.access_token);
    } catch (e) { setError(e instanceof Error ? e.message : "Erro inesperado"); }
    finally { setLoading(false); }
  }

  async function verifyMfa(event: React.FormEvent) {
    event.preventDefault(); setLoading(true); setError("");
    try {
      const result = await api<AuthResult>("/auth/2fa/verify", { method: "POST", body: JSON.stringify({ code }) }, challenge);
      setToken(result.access_token); setTokenState(result.access_token);
    } catch (e) { setError(e instanceof Error ? e.message : "Código inválido"); }
    finally { setLoading(false); }
  }

  function logout() {
    clearToken(); setTokenState(null); setUser(null); setOrganization(null); setMode("login"); setCode("");
  }

  if (!token || !user || !organization) {
    return (
      <main className="auth-shell">
        <div className="auth-glow glow-one" /><div className="auth-glow glow-two" />
        <section className="auth-card">
          <div className="brand"><div className="brand-mark"><Network size={22}/></div><div><b>AgentOS</b><small>INTELLIGENCE PLATFORM</small></div></div>
          <div className="auth-heading">
            <span className="eyebrow"><Sparkles size={13}/> AI WORKFORCE PLATFORM</span>
            <h1>{mode === "register" ? "Construa sua equipe de IA." : mode === "mfa" ? "Verificação de segurança." : "O futuro do trabalho começa aqui."}</h1>
            <p>{mode === "register" ? "Crie seu workspace e comece a organizar sua operação inteligente." : mode === "mfa" ? "Sua conta está protegida com autenticação em dois fatores." : "Entre no seu workspace e gerencie sua inteligência artificial."}</p>
          </div>
          {mode !== "mfa" ? (
            <>
              <div className="auth-tabs"><button className={mode === "login" ? "active" : ""} onClick={() => {setMode("login");setError("");}}>Entrar</button><button className={mode === "register" ? "active" : ""} onClick={() => {setMode("register");setError("");}}>Criar conta</button></div>
              <form onSubmit={submitAuth} className="form">
                {mode === "register" && <><label>Nome completo<input required minLength={2} value={form.full_name} onChange={e=>update("full_name",e.target.value)} placeholder="Seu nome"/></label><label>Nome da empresa<input required minLength={2} value={form.organization_name} onChange={e=>update("organization_name",e.target.value)} placeholder="Sua empresa"/></label></>}
                <label>E-mail<input required type="email" value={form.email} onChange={e=>update("email",e.target.value)} placeholder="voce@empresa.com"/></label>
                <label>Senha<input required type="password" minLength={mode === "register" ? 10 : 1} value={form.password} onChange={e=>update("password",e.target.value)} placeholder={mode === "register" ? "Mínimo de 10 caracteres" : "Sua senha"}/></label>
                <button className="primary-btn" disabled={loading}>{loading ? "Aguarde..." : mode === "register" ? "Criar workspace" : "Entrar no AgentOS"} <ArrowRight size={17}/></button>
              </form>
              <div className="or"><span/>ou continue com<span/></div>
              <button className="google-btn" onClick={()=>window.location.href=googleLoginUrl()}><span className="google-g">G</span> Continuar com Google</button>
              <p className="fineprint">Ao continuar, você concorda com os termos de uso e a política de privacidade.</p>
            </>
          ) : (
            <form onSubmit={verifyMfa} className="form">
              <label>Código de autenticação<input required inputMode="numeric" maxLength={8} value={code} onChange={e=>setCode(e.target.value)} placeholder="000000"/></label>
              <button className="primary-btn" disabled={loading}>Verificar código <ArrowRight size={17}/></button>
              <button type="button" className="text-btn" onClick={()=>{setMode("login");setCode("");}}>Voltar ao login</button>
            </form>
          )}
          {error && <div className="alert error">{error}</div>}{notice && <div className="alert success">{notice}</div>}
          <div className="auth-footer"><ShieldCheck size={14}/> Ambiente seguro · AgentOS v0.1</div>
        </section>
        <aside className="auth-side"><div className="orbital"><div className="orbit orbit-a"/><div className="orbit orbit-b"/><div className="orb-core"><Network size={48}/></div><span className="orbit-node node-a"><Bot/></span><span className="orbit-node node-b"><Workflow/></span><span className="orbit-node node-c"><Cpu/></span></div><h2>One platform.<br/><em>Infinite intelligence.</em></h2><p>Crie, conecte e coordene agentes de IA para transformar a operação da sua empresa.</p><div className="side-stats"><div><b>AI</b><small>ORCHESTRATION</small></div><div><b>∞</b><small>POSSIBILITIES</small></div><div><b>24/7</b><small>READY TO SCALE</small></div></div></aside>
      </main>
    );
  }

  return <Shell user={user} organization={organization} onLogout={logout} onUser={setUser} />;
}
