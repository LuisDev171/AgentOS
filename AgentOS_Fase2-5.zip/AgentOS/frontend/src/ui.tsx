import type { ReactNode } from "react";

export const errMsg = (e: unknown, fallback = "Erro inesperado") => (e instanceof Error ? e.message : fallback);

export function fmtDate(value?: string | null) {
  if (!value) return "—";
  const iso = /[zZ]|[+-]\d\d:?\d\d$/.test(value) ? value : value + "Z"; // o backend envia UTC
  return new Date(iso).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" });
}

export const fmtNum = (n: number) => n.toLocaleString("pt-BR");

export function Banner({ error, notice }: { error?: string; notice?: string }) {
  return <>{error && <div className="alert error">{error}</div>}{notice && <div className="alert success">{notice}</div>}</>;
}

export function Field({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) {
  return <label className="field"><span>{label}</span>{children}{hint && <small>{hint}</small>}</label>;
}

export function PageHeader({ eyebrow, title, subtitle, action }: { eyebrow: string; title: string; subtitle?: string; action?: ReactNode }) {
  return (
    <div className="welcome-row">
      <div><span className="eyebrow">{eyebrow}</span><h1>{title}</h1>{subtitle && <p>{subtitle}</p>}</div>
      {action}
    </div>
  );
}

export function Empty({ children }: { children: ReactNode }) {
  return <div className="empty">{children}</div>;
}

export type Page = "overview" | "agents" | "workflows" | "knowledge" | "executions" | "integrations" | "billing" | "security";
export type Ctx = { role: string; canManage: boolean; go: (page: Page) => void };
