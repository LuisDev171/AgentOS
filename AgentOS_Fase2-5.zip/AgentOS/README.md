# AgentOS

Plataforma SaaS multiempresa para criação e gerenciamento de agentes de inteligência artificial.

## Stack

- Frontend: React, TypeScript, Vite e CSS.
- Backend: Python, FastAPI, SQLAlchemy.
- Dados: PostgreSQL e Alembic.
- Cache/fila preparada: Redis.
- Autenticação: JWT, senha com Argon2id, Google OAuth opcional e TOTP (2FA).
- Infraestrutura local: Docker Compose (opcional) ou execução sem Docker.
- IA: adaptadores próprios (via HTTP) para OpenAI, Anthropic e Google Gemini.

## Requisitos

- Windows 10/11
- Visual Studio Code
- Docker Desktop com WSL2 habilitado
- Git (opcional)
- Node.js 20 ou superior (necessário apenas para executar o frontend fora do Docker)
- Python 3.12 (necessário apenas para executar o backend fora do Docker; veja a seção 5)

## 1. Preparar o projeto

1. Extraia a pasta `AgentOS`.
2. Abra o VS Code.
3. Clique em **File > Open Folder** e selecione a pasta `AgentOS`.
4. Abra **Terminal > New Terminal**.
5. Copie `.env.example` para `.env`:

   ```powershell
   Copy-Item .env.example .env
   ```

6. Abra `.env`. Para desenvolvimento local, os valores padrão podem ser usados. Troque `JWT_SECRET_KEY` por uma chave aleatória longa. Não compartilhe o `.env`.

## 2. Iniciar com Docker (recomendado)

1. Abra o Docker Desktop e aguarde ficar pronto.
2. No terminal do VS Code, dentro da pasta `AgentOS`, execute:

   ```powershell
   docker compose up --build
   ```

3. Aguarde os serviços iniciarem.
4. Abra:
   - Frontend: http://localhost:5173
   - API: http://localhost:8000
   - Documentação interativa: http://localhost:8000/docs
   - Health check: http://localhost:8000/health

Na primeira inicialização, o backend cria as tabelas para facilitar o ambiente de desenvolvimento. Para ambientes reais, use as migrações Alembic e não dependa de `create_all`.

Para encerrar: `Ctrl + C`, depois `docker compose down`. Os dados do PostgreSQL continuam no volume Docker.
Para apagar também o banco local: `docker compose down -v` (isso apaga os dados de desenvolvimento).

## 3. Criar a primeira conta

1. Acesse http://localhost:5173.
2. Escolha **Criar conta**.
3. Informe nome, e-mail, senha e nome da empresa.
4. Depois de entrar, use **Ativar autenticação em dois fatores**.
5. Escaneie o QR code com um aplicativo autenticador compatível e informe o código de seis dígitos.

## 4. Configurar login Google

O login por Google exige credenciais OAuth criadas no Google Cloud Console.

1. Crie um projeto no Google Cloud.
2. Configure a tela de consentimento OAuth.
3. Crie um OAuth Client ID do tipo Web application.
4. Adicione `http://localhost:8000/api/v1/auth/google/callback` como URI de redirecionamento autorizado.
5. Preencha `GOOGLE_CLIENT_ID` e `GOOGLE_CLIENT_SECRET` no `.env`.
6. Reinicie os serviços:

   ```powershell
   docker compose up --build
   ```

Sem essas credenciais, o botão Google informa que o recurso ainda não foi configurado. O login por e-mail continua disponível.

## 5. Executar sem Docker (Windows)

Não precisa de Docker, PostgreSQL nem Redis: o banco é um arquivo local (`backend/agentos.db`).

Requisitos:

- **Python 3.12** (recomendado; 3.11 e 3.13 também funcionam). Python 3.14 ou mais novo ainda não é compatível com as versões travadas das bibliotecas. Baixe em python.org e marque **Add python.exe to PATH**.
- **Node.js 20 ou superior** (versão LTS em nodejs.org).

### Jeito fácil

Dê dois cliques em **`iniciar-sem-docker.bat`**. Ele cria o ambiente Python, instala tudo, inicia a API e o site em duas janelas e abre http://localhost:5173. Para encerrar, feche as duas janelas.

### Jeito manual (dois terminais)

Backend, dentro da pasta `AgentOS`:

```powershell
cd backend
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
Copy-Item .env.example .env
.\.venv\Scripts\python.exe -m uvicorn app.main:app --reload --port 8000
```

Frontend (outro terminal), dentro da pasta `AgentOS`:

```powershell
cd frontend
npm install
Copy-Item .env.example .env
npm run dev
```

Para usar PostgreSQL próprio em vez do arquivo local, ajuste `DATABASE_URL` em `backend/.env`.

## Endpoints iniciais

- `POST /api/v1/auth/register` — cria usuário, empresa e associação de proprietário.
- `POST /api/v1/auth/login` — login por e-mail e senha.
- `GET /api/v1/auth/me` — usuário autenticado.
- `POST /api/v1/auth/2fa/setup` — inicia configuração TOTP.
- `POST /api/v1/auth/2fa/confirm` — confirma e ativa TOTP.
- `POST /api/v1/auth/2fa/verify` — conclui login que exige 2FA.
- `GET /api/v1/auth/google/login` — inicia OAuth Google.
- `GET /api/v1/auth/google/callback` — callback OAuth.
- `GET /api/v1/organizations/current` — organização atual.

(Endpoints das fases 2–5 estão na seção seguinte.)

## Segurança e limitações desta base

- Esta é uma base de desenvolvimento, não uma implantação pronta para produção.
- O frontend guarda o access token em `sessionStorage` para simplificar o MVP. Antes de produção, migre para cookies `HttpOnly`, `Secure`, `SameSite`, proteção CSRF e uma estratégia de refresh/revogação.
- Configure HTTPS, domínio, segredos fortes, backups, monitoramento, política de retenção e limites de uso antes de atender clientes.
- O segredo TOTP é armazenado no banco nesta base inicial; em produção, criptografe-o com uma chave gerenciada fora do banco.
- OAuth Google precisa ser configurado no console do Google.
- As chaves OpenAI/Gemini/Anthropic são cadastradas pela tela Integrations (as variáveis `*_API_KEY` do `.env` não são usadas).
- A tabela de organizações e a dependência de organização atual já estabelecem a fundação multi-tenant. Antes de produção, complete testes de isolamento e políticas de autorização em todos os recursos.

## Fases 2 a 5 (o que foi adicionado)

Depois de entrar, o menu lateral passa a ter:

| Tela | O que faz |
| --- | --- |
| **Overview** | Métricas dos últimos 14 dias, gráfico de execuções e checklist de primeiros passos. |
| **My Agents** | Agent Studio: criar/editar agentes (provedor, modelo, instruções, temperatura, ferramentas autorizadas, bases de conhecimento) e **Playground** de conversa com histórico salvo. |
| **Workflows** | Sequência de passos (agente de IA, texto/formatação, requisição HTTP) com variáveis `{{input}}`, `{{last}}` e `{{steps.ID.output}}`. |
| **Knowledge Base** | Documentos de texto divididos em trechos e pesquisados por palavras-chave (BM25). O agente consulta pela ferramenta `search_knowledge`. |
| **Executions** | Registro de toda execução (status, tokens, tempo, entrada, saída e rastro de ferramentas/passos). |
| **Integrations** | Chaves dos provedores de IA (criptografadas) e chaves de API do AgentOS para chamar agentes/workflows de fora. |
| **Billing & Usage** | Plano (Free/Pro/Business), consumo do mês e limites aplicados de verdade. |

### Primeiro uso (passo a passo)

1. Rode o projeto (seção 2 ou 5) e entre na sua conta.
2. Vá em **Integrations**, cole a chave de API de pelo menos um provedor (OpenAI, Anthropic ou Gemini) e clique em **Salvar**. Quem paga o uso da IA é a sua conta no provedor.
3. Vá em **My Agents > Novo agente**, escolha o provedor e o modelo e salve.
4. Converse com o agente no **Playground**, logo abaixo do formulário.
5. (Opcional) Crie uma base em **Knowledge Base**, adicione documentos, marque a base no agente e pergunte sobre o conteúdo.
6. (Opcional) Monte um **Workflow** e execute.

> Os nomes de modelos sugeridos na lista podem ficar desatualizados com o tempo. O campo aceita qualquer nome: se o provedor responder "modelo não encontrado", use um nome atual da documentação dele.

### Ferramentas disponíveis para agentes

`current_time` (data/hora), `calculator` (cálculo seguro), `http_get` (lê uma URL pública; bloqueia endereços internos/privados) e `search_knowledge` (ativada automaticamente quando o agente tem uma base de conhecimento). O agente só consegue executar as ferramentas marcadas nele; qualquer outra chamada é recusada.

### Chamar de outros sistemas (API pública)

Em **Integrations > Chaves de API do AgentOS**, gere uma chave (ela só aparece uma vez) e use:

```bash
curl -X POST http://localhost:8000/api/v1/public/agents/ID_DO_AGENTE/run \
  -H "X-API-Key: SUA_CHAVE" -H "Content-Type: application/json" \
  -d '{"input": "Olá!"}'
```

Para workflows: `/api/v1/public/workflows/ID_DO_WORKFLOW/run`. Há limite de 60 requisições por minuto por chave (em memória, por processo).

### Novos endpoints (resumo; veja `/docs`)

- `GET /providers`, `PUT|DELETE /providers/{provedor}/key`, `GET /tools`
- `GET|POST /agents`, `GET|PUT|DELETE /agents/{id}`, `POST /agents/{id}/chat`, `GET /agents/{id}/conversations`, `GET|DELETE /conversations/{id}`
- `GET|POST /knowledge-bases`, `DELETE /knowledge-bases/{id}`, `GET|POST /knowledge-bases/{id}/documents`, `GET /knowledge-bases/{id}/search`
- `GET|POST /workflows`, `PUT|DELETE /workflows/{id}`, `POST /workflows/{id}/run`
- `GET /executions`, `GET /executions/{id}`, `GET /metrics/overview`
- `GET|POST /api-keys`, `DELETE /api-keys/{id}`
- `GET /billing`, `POST /billing/plan`
- `POST /public/agents/{id}/run`, `POST /public/workflows/{id}/run` (header `X-API-Key`)

Permissões: proprietário e administrador criam/editam/excluem e gerenciam chaves; membros usam agentes e workflows e veem execuções. Todas as consultas são filtradas pela organização do usuário.

### Banco de dados

Em desenvolvimento, as tabelas novas são criadas automaticamente na inicialização (o `agentos.db` da Fase 1 continua funcionando, sem perder dados). Com PostgreSQL em ambiente real, rode `alembic upgrade head` dentro de `backend` (a migração `0002` cria as tabelas novas).

### Testes

```powershell
cd backend
.\.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
.\.venv\Scripts\python.exe -m pytest -q
```

Os testes cobrem os adaptadores dos três provedores (com respostas simuladas, sem rede), as ferramentas, o laço do agente, a busca e as variáveis de workflow.

## Limitações conhecidas (leia antes de usar com clientes)

- **Faturamento é só contagem de uso e limites.** Não há cobrança real: a troca de plano apenas altera os limites. Integrar um processador de pagamento (ex.: Stripe) ainda é necessário.
- **Chaves dos provedores** ficam criptografadas (Fernet) no banco. Defina `ENCRYPTION_KEY` no `.env` **antes** de cadastrar chaves e não troque depois; sem ela, a chave é derivada de `JWT_SECRET_KEY` e trocar o segredo invalida as chaves salvas.
- **Knowledge Base** usa busca por palavras-chave (sem embeddings) e aceita só texto (.txt, .md, .csv, .json); PDF/Word ainda não. Funciona bem para dezenas de documentos; para bases grandes, migrar para busca vetorial (pgvector).
- **Execuções são síncronas**: a requisição espera o modelo responder (até ~90 s por chamada). Não há fila, agendamento nem respostas em streaming. Redis continua apenas reservado.
- **Limite de requisições da API pública** é em memória (por processo); use Redis se rodar vários processos.
- **Workflows** são lineares (sem condições/loops/paralelismo) e sem gatilhos automáticos além da API.
- **Integrações** de terceiros prontas (Slack, e-mail, Google etc.) não existem; hoje a integração é via passo HTTP e API pública.
- O código foi escrito e revisado sem poder instalar as dependências do backend no ambiente de desenvolvimento do assistente. A lógica central é coberta por testes, mas as rotas e as telas devem ser testadas por você na primeira execução; se algo falhar, copie a mensagem de erro.
- Itens de segurança da Fase 1 continuam valendo (token em `sessionStorage`, TOTP sem criptografia, HTTPS/backup/monitoramento).

## Próximos passos sugeridos

1. Integrar pagamento (Stripe) e e-mails transacionais.
2. Busca vetorial na Knowledge Base e upload de PDF/Word.
3. Fila de execução (Redis + worker), streaming de respostas e agendamento de workflows.
4. Workflows com condições/ramificações, mais ferramentas e conectores (Slack, e-mail, planilhas).
5. Convite de membros e papéis, logs de auditoria e testes de isolamento entre organizações.
