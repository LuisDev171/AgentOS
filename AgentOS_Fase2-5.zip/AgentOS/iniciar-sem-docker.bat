@echo off
setlocal
cd /d "%~dp0"
title AgentOS - iniciar sem Docker
echo ==========================================
echo   AgentOS - iniciar sem Docker
echo ==========================================
echo.

set PYV=
for %%v in (3.12 3.13 3.11) do (
  if not defined PYV (
    py -%%v --version >nul 2>nul
    if not errorlevel 1 set PYV=%%v
  )
)
if not defined PYV (
  echo Python 3.12 nao encontrado.
  echo Instale o Python 3.12 em https://www.python.org/downloads/release/python-3129/
  echo e marque "Add python.exe to PATH" na instalacao. Depois rode este arquivo de novo.
  echo ^(Python 3.14 ou mais novo ainda nao funciona com as bibliotecas do projeto.^)
  pause
  exit /b 1
)
echo Usando Python %PYV%

where npm >nul 2>nul
if errorlevel 1 (
  echo Node.js nao encontrado.
  echo Instale a versao LTS em https://nodejs.org e rode este arquivo de novo.
  pause
  exit /b 1
)

echo.
echo [1/4] Preparando o backend...
if not exist backend\.venv (
  py -%PYV% -m venv backend\.venv
  if errorlevel 1 goto erro
)
backend\.venv\Scripts\python.exe -m pip install --upgrade pip -q
backend\.venv\Scripts\python.exe -m pip install -r backend\requirements.txt
if errorlevel 1 goto erro
if not exist backend\.env copy backend\.env.example backend\.env >nul

echo.
echo [2/4] Preparando o site...
if not exist frontend\.env copy frontend\.env.example frontend\.env >nul
if not exist frontend\node_modules (
  pushd frontend
  call npm install
  if errorlevel 1 (
    popd
    goto erro
  )
  popd
)

echo.
echo [3/4] Iniciando os servidores em duas janelas...
start "AgentOS API" /d "%~dp0backend" cmd /k ".venv\Scripts\python.exe -m uvicorn app.main:app --reload --port 8000"
start "AgentOS Site" /d "%~dp0frontend" cmd /k "npm run dev"

echo.
echo [4/4] Abrindo o navegador em alguns segundos...
timeout /t 10 /nobreak >nul
start "" http://localhost:5173
echo.
echo Pronto! Site: http://localhost:5173   API: http://localhost:8000/docs
echo Para encerrar, feche as duas janelas pretas "AgentOS API" e "AgentOS Site".
pause
exit /b 0

:erro
echo.
echo Algo deu errado. Copie a mensagem acima e envie para o suporte.
pause
exit /b 1
